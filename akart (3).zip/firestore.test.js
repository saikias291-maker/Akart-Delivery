const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const MASTER_ADMIN_UID = "master_admin_uid_001";
const PARTNER_ZOO_UID = "partner_zoo_uid_002";
const ALICE_UID = "alice_uid_101";
const BOB_UID = "bob_uid_202";

const AREA_ZOO = "guwahati_zoo_road";
const AREA_JORHAT = "jorhat_gar_ali";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastDate(msAgo = 5000) {
  return new Date(Date.now() - msAgo);
}

async function seedStaffAndCatalog() {
  const created = pastDate(20000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const adminDb = ctx.firestore();
    await adminDb.collection("staffRoles").doc(MASTER_ADMIN_UID).set({
      userId: MASTER_ADMIN_UID,
      role: "MASTER_ADMIN",
      assignedAreaId: "",
      active: true,
      createdAt: created,
      updatedAt: created,
    });
    await adminDb.collection("staffRoles").doc(PARTNER_ZOO_UID).set({
      userId: PARTNER_ZOO_UID,
      role: "AREA_PARTNER",
      assignedAreaId: AREA_ZOO,
      active: true,
      createdAt: created,
      updatedAt: created,
    });
    await adminDb.collection("areas").doc(AREA_ZOO).set({
      areaId: AREA_ZOO,
      name: "Zoo Road Tiniali, Guwahati",
      city: "Guwahati",
      hubName: "Zoo Road Dark Store",
      pinCodes: ["781024"],
      defaultEtaMins: 12,
      active: true,
      createdAt: created,
      updatedAt: created,
    });
    await adminDb.collection("areas").doc(AREA_JORHAT).set({
      areaId: AREA_JORHAT,
      name: "Gar-Ali, Jorhat",
      city: "Jorhat",
      hubName: "Jorhat Central Hub",
      pinCodes: ["785001"],
      defaultEtaMins: 18,
      active: true,
      createdAt: created,
      updatedAt: created,
    });
    await adminDb.collection("categories").doc("tea").set({
      categoryId: "tea",
      title: "Assam Tea & Brews",
      shortTitle: "Assam Tea",
      tagline: "Single-estate gardens",
      imageUrl: "https://example.com/tea.jpg",
      sortOrder: 1,
      active: true,
      createdAt: created,
      updatedAt: created,
    });
    await adminDb.collection("products").doc("tea_orthodox_gold").set({
      productId: "tea_orthodox_gold",
      name: "Upper Assam Orthodox Gold Tea",
      unit: "250 g",
      categoryId: "tea",
      origin: "Dibrugarh Estate",
      basePriceRupees: 245,
      baseMrpRupees: 290,
      rating: 4.9,
      reviewCount: 412,
      deliveryMins: 12,
      description: "Whole-leaf second flush orthodox black tea.",
      highlights: ["Second Flush Whole Leaf"],
      imageUrl: "https://example.com/orthodox.jpg",
      photoUrls: ["https://example.com/orthodox.jpg"],
      giTagged: true,
      featuredDeal: true,
      lowStock: false,
      active: true,
      createdAt: created,
      updatedAt: created,
    });
    await adminDb.collection("areaPrices").doc(`${AREA_ZOO}__tea_orthodox_gold`).set({
      areaId: AREA_ZOO,
      productId: "tea_orthodox_gold",
      priceRupees: 240,
      mrpRupees: 290,
      deliveryMins: 12,
      available: true,
      stockCount: 40,
      createdAt: created,
      updatedAt: created,
    });
    await adminDb.collection("areaPrices").doc(`${AREA_JORHAT}__tea_orthodox_gold`).set({
      areaId: AREA_JORHAT,
      productId: "tea_orthodox_gold",
      priceRupees: 255,
      mrpRupees: 290,
      deliveryMins: 18,
      available: true,
      stockCount: 18,
      createdAt: created,
      updatedAt: created,
    });
  });
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Mobile customer context cannot access staffRoles, dump all users, query collectionGroup orders, or modify admin/catalog data", async () => {
  await seedStaffAndCatalog();
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const past = pastDate();

  // Allowed: read storefront catalog & service areas
  await assertSucceeds(unauthDb.collection("areas").get());
  await assertSucceeds(unauthDb.collection("categories").get());
  await assertSucceeds(unauthDb.collection("products").get());
  await assertSucceeds(unauthDb.collection("areaPrices").where("areaId", "==", AREA_ZOO).get());

  // Denied: read staffRoles, unbounded /users listing, collectionGroup orders, or write admin/catalog docs
  await assertFails(unauthDb.collection("staffRoles").doc(PARTNER_ZOO_UID).get());
  await assertFails(unauthDb.collection("staffRoles").get());
  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("users").limit(10).get());
  await assertFails(unauthDb.collectionGroup("orders").get());
  await assertFails(
    unauthDb.collection("products").doc("hack").set({
      productId: "hack",
      name: "Hack",
      createdAt: past,
      updatedAt: past,
    })
  );
  await assertFails(
    unauthDb.collection("areaPrices").doc(`${AREA_ZOO}__tea_orthodox_gold`).update({
      priceRupees: 1,
      updatedAt: past,
    })
  );
  await assertFails(
    unauthDb.collection("areas").doc("fake_area").set({
      areaId: "fake_area",
      name: "Fake",
      city: "Nowhere",
      hubName: "Fake Hub",
      pinCodes: ["781001"],
      defaultEtaMins: 10,
      active: true,
      createdAt: past,
      updatedAt: past,
    })
  );
});

test("Mobile customer registration, 10-digit lookup, permanent area lock, and order/price tampering protection", async () => {
  await seedStaffAndCatalog();
  const custDb = testEnv.unauthenticatedContext().firestore();
  const created = pastDate(10000);
  const custId = "cust_9876543210abcdef";

  // Denied: invalid 9-digit phone or missing primaryAreaId
  await assertFails(
    custDb.collection("users").doc("cust_bad_phone").set({
      userId: "cust_bad_phone",
      displayName: "Bad Phone",
      phone: "986401234",
      primaryAreaId: AREA_ZOO,
      leaveAtDoor: false,
      ecoClothBag: true,
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertFails(
    custDb.collection("users").doc("cust_no_area").set({
      userId: "cust_no_area",
      displayName: "No Area",
      phone: "9864012345",
      primaryAreaId: "",
      leaveAtDoor: false,
      ecoClothBag: true,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Allowed: atomic batch registration of customer + primary address in chosen area
  const batch = custDb.batch();
  batch.set(custDb.collection("users").doc(custId), {
    userId: custId,
    displayName: "Bhaskar Das",
    phone: "9864012345",
    primaryAreaId: AREA_ZOO,
    leaveAtDoor: false,
    ecoClothBag: true,
    createdAt: created,
    updatedAt: created,
  });
  batch.set(custDb.collection("users").doc(custId).collection("addresses").doc("addr_primary"), {
    userId: custId,
    areaId: AREA_ZOO,
    label: "Home",
    area: "Zoo Road Tiniali, Guwahati",
    fullAddress: "House 14, Bylane 3, Zoo Road",
    pinCode: "781024",
    hubName: "Zoo Road Dark Store",
    etaMins: 12,
    selected: true,
    createdAt: created,
    updatedAt: created,
  });
  await assertSucceeds(batch.commit());

  // Allowed: mobile lookup with limit <= 5
  await assertSucceeds(
    custDb.collection("users").where("phone", "in", ["9864012345"]).limit(5).get()
  );

  // Denied: customer cannot switch registered primaryAreaId after registration
  await assertFails(
    custDb.collection("users").doc(custId).update({
      primaryAreaId: AREA_JORHAT,
      updatedAt: pastDate(500),
    })
  );

  // Denied: customer cannot add an address or place an order in another area
  await assertFails(
    custDb.collection("users").doc(custId).collection("addresses").doc("addr_other").set({
      userId: custId,
      areaId: AREA_JORHAT,
      label: "Work",
      area: "Gar-Ali, Jorhat",
      fullAddress: "Jorhat Club Road",
      pinCode: "785001",
      hubName: "Jorhat Central Hub",
      etaMins: 18,
      selected: false,
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    custDb.collection("users").doc(custId).collection("orders").doc("AKM-9901").set({
      userId: custId,
      areaId: AREA_JORHAT,
      addressLabel: "Home",
      addressSummary: "Gar-Ali, Jorhat • 785001",
      deliverySlot: "Express 12 min",
      paymentMethod: "Cash on Delivery",
      itemCount: 1,
      itemsSummary: "Tea x1",
      productIdsCsv: "tea_orthodox_gold:1",
      subtotalRupees: 255,
      deliveryFeeRupees: 0,
      discountRupees: 0,
      totalRupees: 255,
      status: "CONFIRMED",
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );

  // Allowed: place order in registered area and update own profile name/phone
  await assertSucceeds(
    custDb.collection("users").doc(custId).update({
      displayName: "Bhaskar Jyoti Das",
      phone: "9864054321",
      updatedAt: pastDate(400),
    })
  );
  await assertSucceeds(
    custDb.collection("users").doc(custId).collection("orders").doc("AKM-9902").set({
      userId: custId,
      areaId: AREA_ZOO,
      addressLabel: "Home",
      addressSummary: "Zoo Road Tiniali, Guwahati • 781024",
      deliverySlot: "Express 12 min",
      paymentMethod: "Cash on Delivery",
      itemCount: 1,
      itemsSummary: "Upper Assam Orthodox Gold Tea ×1",
      productIdsCsv: "tea_orthodox_gold:1",
      subtotalRupees: 240,
      deliveryFeeRupees: 0,
      discountRupees: 0,
      totalRupees: 240,
      status: "CONFIRMED",
      createdAt: pastDate(300),
      updatedAt: pastDate(300),
    })
  );

  // Denied: customer cannot alter order total or delete order
  await assertFails(
    custDb.collection("users").doc(custId).collection("orders").doc("AKM-9902").update({
      totalRupees: 1,
      updatedAt: pastDate(200),
    })
  );
  await assertFails(
    custDb.collection("users").doc(custId).collection("orders").doc("AKM-9902").delete()
  );
});

test("Master Admin has full management permissions across areas, categories, products, photographs, areaPrices, customers, and orders", async () => {
  await seedStaffAndCatalog();
  const adminDb = testEnv.authenticatedContext(MASTER_ADMIN_UID).firestore();
  const now = pastDate(2000);

  // Manage areas
  await assertSucceeds(
    adminDb.collection("areas").doc("dibrugarh_campus").set({
      areaId: "dibrugarh_campus",
      name: "Dibrugarh University Gate",
      city: "Dibrugarh",
      hubName: "Dibrugarh South Hub",
      pinCodes: ["786004"],
      defaultEtaMins: 20,
      active: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Manage categories
  await assertSucceeds(
    adminDb.collection("categories").doc("crafts").set({
      categoryId: "crafts",
      title: "Weaves & Home",
      shortTitle: "Crafts",
      tagline: "Sualkuchi & bamboo",
      imageUrl: "https://example.com/crafts.jpg",
      sortOrder: 6,
      active: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Add, edit, update photos, and delete products
  await assertSucceeds(
    adminDb.collection("products").doc("craft_phulam_gamosa").set({
      productId: "craft_phulam_gamosa",
      name: "Handwoven Cotton Phulam Gamosa",
      unit: "1 pc",
      categoryId: "crafts",
      origin: "Sualkuchi",
      basePriceRupees: 195,
      baseMrpRupees: 250,
      rating: 4.9,
      reviewCount: 510,
      deliveryMins: 15,
      description: "Authentic GI-tagged handloom cotton gamosa.",
      highlights: ["GI-Tagged Handloom"],
      imageUrl: "https://example.com/gamosa.jpg",
      photoUrls: ["https://example.com/gamosa1.jpg", "https://example.com/gamosa2.jpg"],
      giTagged: true,
      featuredDeal: false,
      lowStock: false,
      active: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    adminDb.collection("products").doc("craft_phulam_gamosa").update({
      imageUrl: "https://example.com/gamosa_v2.jpg",
      updatedAt: pastDate(500),
    })
  );

  // Manage area-wise prices
  await assertSucceeds(
    adminDb.collection("areaPrices").doc("dibrugarh_campus__craft_phulam_gamosa").set({
      areaId: "dibrugarh_campus",
      productId: "craft_phulam_gamosa",
      priceRupees: 205,
      mrpRupees: 250,
      deliveryMins: 20,
      available: true,
      stockCount: 15,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(adminDb.collection("products").doc("craft_phulam_gamosa").delete());
  await assertSucceeds(adminDb.collection("users").get());
  await assertSucceeds(adminDb.collectionGroup("orders").get());
});

test("Area Partner can access and manage deliveries ONLY for assigned area; blocked from products, prices, and other areas", async () => {
  await seedStaffAndCatalog();
  const created = pastDate(15000);

  // Seed Alice (Zoo Road) and Bob (Jorhat) with profiles and orders
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Zoo",
      phone: "+91 98640 11111",
      primaryAreaId: AREA_ZOO,
      leaveAtDoor: false,
      ecoClothBag: true,
      createdAt: created,
      updatedAt: created,
    });
    await db.collection("users").doc(ALICE_UID).collection("orders").doc("AKM-3001").set({
      userId: ALICE_UID,
      areaId: AREA_ZOO,
      addressLabel: "Home",
      addressSummary: "Zoo Road Tiniali • 781024",
      deliverySlot: "Express 12 min",
      paymentMethod: "UPI",
      itemCount: 1,
      itemsSummary: "Tea x1",
      productIdsCsv: "tea_orthodox_gold:1",
      subtotalRupees: 240,
      deliveryFeeRupees: 0,
      discountRupees: 0,
      totalRupees: 240,
      status: "CONFIRMED",
      createdAt: created,
      updatedAt: created,
    });
    await db.collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      displayName: "Bob Jorhat",
      phone: "+91 98640 22222",
      primaryAreaId: AREA_JORHAT,
      leaveAtDoor: false,
      ecoClothBag: true,
      createdAt: created,
      updatedAt: created,
    });
    await db.collection("users").doc(BOB_UID).collection("orders").doc("AKM-3002").set({
      userId: BOB_UID,
      areaId: AREA_JORHAT,
      addressLabel: "Home",
      addressSummary: "Gar-Ali, Jorhat • 785001",
      deliverySlot: "Express 18 min",
      paymentMethod: "UPI",
      itemCount: 1,
      itemsSummary: "Tea x1",
      productIdsCsv: "tea_orthodox_gold:1",
      subtotalRupees: 255,
      deliveryFeeRupees: 0,
      discountRupees: 0,
      totalRupees: 255,
      status: "CONFIRMED",
      createdAt: created,
      updatedAt: created,
    });
  });

  const partnerDb = testEnv.authenticatedContext(PARTNER_ZOO_UID).firestore();

  // Allowed: read assigned area, assigned area's prices, assigned area's customers & orders
  await assertSucceeds(partnerDb.collection("areas").doc(AREA_ZOO).get());
  await assertSucceeds(partnerDb.collection("areaPrices").where("areaId", "==", AREA_ZOO).get());
  await assertSucceeds(partnerDb.collection("users").where("primaryAreaId", "==", AREA_ZOO).get());
  await assertSucceeds(partnerDb.collection("users").doc(ALICE_UID).get());
  await assertSucceeds(partnerDb.collectionGroup("orders").where("areaId", "==", AREA_ZOO).get());

  // Allowed: update order status & delivery note for assigned area
  await assertSucceeds(
    partnerDb.collection("users").doc(ALICE_UID).collection("orders").doc("AKM-3001").update({
      status: "OUT_FOR_DELIVERY",
      deliveryPartnerNote: "Rider Dispatched",
      updatedAt: pastDate(1000),
    })
  );

  // Denied: tamper with order total or areaId
  await assertFails(
    partnerDb.collection("users").doc(ALICE_UID).collection("orders").doc("AKM-3001").update({
      totalRupees: 999,
      updatedAt: pastDate(500),
    })
  );

  // Denied: access OTHER area (Jorhat) or unfiltered queries
  await assertFails(partnerDb.collection("areas").doc(AREA_JORHAT).get());
  await assertFails(partnerDb.collection("areas").get());
  await assertFails(partnerDb.collection("areaPrices").where("areaId", "==", AREA_JORHAT).get());
  await assertFails(partnerDb.collection("areaPrices").get());
  await assertFails(partnerDb.collection("users").doc(BOB_UID).get());
  await assertFails(partnerDb.collection("users").where("primaryAreaId", "==", AREA_JORHAT).get());
  await assertFails(partnerDb.collection("users").get());
  await assertFails(partnerDb.collectionGroup("orders").where("areaId", "==", AREA_JORHAT).get());
  await assertFails(partnerDb.collectionGroup("orders").get());
  await assertFails(
    partnerDb.collection("users").doc(BOB_UID).collection("orders").doc("AKM-3002").update({
      status: "PACKED",
      updatedAt: pastDate(500),
    })
  );

  // Denied: add, edit, or delete products, categories, or prices
  await assertFails(
    partnerDb.collection("products").doc("tea_orthodox_gold").update({
      basePriceRupees: 100,
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    partnerDb.collection("products").doc("tea_new").set({
      productId: "tea_new",
      name: "Unauthorized Tea",
      unit: "250 g",
      categoryId: "tea",
      origin: "Assam",
      basePriceRupees: 100,
      baseMrpRupees: 120,
      rating: 4.5,
      reviewCount: 1,
      deliveryMins: 12,
      description: "Test",
      highlights: [],
      imageUrl: "https://example.com/x.jpg",
      giTagged: false,
      featuredDeal: false,
      lowStock: false,
      active: true,
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
  await assertFails(partnerDb.collection("products").doc("tea_orthodox_gold").delete());
  await assertFails(
    partnerDb.collection("areaPrices").doc(`${AREA_ZOO}__tea_orthodox_gold`).update({
      priceRupees: 199,
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    partnerDb.collection("categories").doc("tea").update({
      title: "Hijacked",
      updatedAt: pastDate(500),
    })
  );

  // Denied: self-escalation to MASTER_ADMIN
  await assertFails(
    partnerDb.collection("staffRoles").doc(PARTNER_ZOO_UID).update({
      role: "MASTER_ADMIN",
      updatedAt: pastDate(500),
    })
  );
});

test("Customer can view areas/products/prices and manage own profile, cart, addresses, and orders; cannot modify catalog or access others", async () => {
  await seedStaffAndCatalog();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = pastDate(10000);

  // Allowed: view areas, categories, products, areaPrices
  await assertSucceeds(aliceDb.collection("areas").get());
  await assertSucceeds(aliceDb.collection("categories").get());
  await assertSucceeds(aliceDb.collection("products").get());
  await assertSucceeds(aliceDb.collection("areaPrices").where("areaId", "==", AREA_ZOO).get());

  // Denied: customer cannot modify products, categories, areas, prices, or staffRoles
  await assertFails(
    aliceDb.collection("products").doc("tea_orthodox_gold").update({
      basePriceRupees: 1,
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    aliceDb.collection("areaPrices").doc(`${AREA_ZOO}__tea_orthodox_gold`).update({
      priceRupees: 1,
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    aliceDb.collection("staffRoles").doc(ALICE_UID).set({
      userId: ALICE_UID,
      role: "MASTER_ADMIN",
      assignedAreaId: "",
      active: true,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Allowed: customer own profile, address, cart, order creation & own order retrieval
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Ananya Saikia",
      phone: "+91 98640 42190",
      primaryAreaId: AREA_ZOO,
      leaveAtDoor: false,
      ecoClothBag: true,
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("addresses").doc("addr_seed_0").set({
      userId: ALICE_UID,
      areaId: AREA_ZOO,
      label: "Home",
      area: "Zoo Road Tiniali, Guwahati",
      fullAddress: "House 14, Bylane 3",
      pinCode: "781024",
      hubName: "Zoo Road Dark Store",
      etaMins: 12,
      selected: true,
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("cartItems").doc("tea_orthodox_gold").set({
      userId: ALICE_UID,
      productId: "tea_orthodox_gold",
      quantity: 1,
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("orders").doc("AKM-4102").set({
      userId: ALICE_UID,
      areaId: AREA_ZOO,
      addressLabel: "Home",
      addressSummary: "Zoo Road Tiniali, Guwahati • 781024",
      deliverySlot: "Express 12 min",
      paymentMethod: "UPI (GPay / PhonePe)",
      itemCount: 1,
      itemsSummary: "Upper Assam Orthodox Gold Tea ×1",
      productIdsCsv: "tea_orthodox_gold:1",
      subtotalRupees: 240,
      deliveryFeeRupees: 0,
      discountRupees: 0,
      totalRupees: 240,
      status: "CONFIRMED",
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("orders").get());

  // Customer cannot set arbitrary partner statuses like PACKED/OUT_FOR_DELIVERY
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("orders").doc("AKM-4102").update({
      status: "OUT_FOR_DELIVERY",
      updatedAt: pastDate(500),
    })
  );

  // Customer CAN mark own order delivered or cancelled (existing UI flow)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("orders").doc("AKM-4102").update({
      status: "DELIVERED",
      updatedAt: pastDate(400),
    })
  );

  // Terminal state lock
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("orders").doc("AKM-4102").update({
      status: "CANCELLED",
      updatedAt: pastDate(200),
    })
  );

  // Cross-customer isolation & listing /users blocked for signed-in Bob
  await assertFails(bobDb.collection("users").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("orders").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("cartItems").get());
});

test("Legacy customer & order docs without primaryAreaId or areaId remain backward-compatible for owner and Master Admin", async () => {
  const created = pastDate(20000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("staffRoles").doc(MASTER_ADMIN_UID).set({
      userId: MASTER_ADMIN_UID,
      role: "MASTER_ADMIN",
      assignedAreaId: "",
      active: true,
      createdAt: created,
      updatedAt: created,
    });
    await db.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Legacy User",
      phone: "+91 98640 00000",
      leaveAtDoor: false,
      ecoClothBag: true,
      createdAt: created,
      updatedAt: created,
    });
    await db.collection("users").doc(ALICE_UID).collection("orders").doc("AKM-2041").set({
      userId: ALICE_UID,
      addressLabel: "Home",
      addressSummary: "Zoo Road Tiniali, Guwahati • 781024",
      deliverySlot: "Express 12 min",
      paymentMethod: "UPI",
      itemCount: 1,
      itemsSummary: "Tea x1",
      productIdsCsv: "tea_orthodox_gold:1",
      subtotalRupees: 245,
      deliveryFeeRupees: 0,
      discountRupees: 0,
      totalRupees: 245,
      status: "CONFIRMED",
      createdAt: created,
      updatedAt: created,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const adminDb = testEnv.authenticatedContext(MASTER_ADMIN_UID).firestore();

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("orders").get());
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      primaryAreaId: AREA_ZOO,
      updatedAt: pastDate(500),
    })
  );
  await assertSucceeds(adminDb.collection("users").doc(ALICE_UID).get());
});

test("Custom Auth claims for MASTER_ADMIN and AREA_PARTNER enforce role & area isolation without staffRoles doc", async () => {
  await seedStaffAndCatalog();
  const created = pastDate(10000);
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(BOB_UID).collection("orders").doc("AKM-5001").set({
      userId: BOB_UID,
      areaId: AREA_JORHAT,
      addressLabel: "Home",
      addressSummary: "Gar-Ali, Jorhat • 785001",
      deliverySlot: "Express 18 min",
      paymentMethod: "UPI",
      itemCount: 1,
      itemsSummary: "Tea x1",
      productIdsCsv: "tea_orthodox_gold:1",
      subtotalRupees: 255,
      deliveryFeeRupees: 0,
      discountRupees: 0,
      totalRupees: 255,
      status: "CONFIRMED",
      createdAt: created,
      updatedAt: created,
    });
  });

  const claimAdminDb = testEnv.authenticatedContext("claim_admin", { role: "MASTER_ADMIN" }).firestore();
  const claimJorhatPartnerDb = testEnv
    .authenticatedContext("claim_jorhat_partner", { role: "AREA_PARTNER", assignedAreaId: AREA_JORHAT })
    .firestore();

  await assertSucceeds(
    claimAdminDb.collection("areaPrices").doc(`${AREA_JORHAT}__tea_orthodox_gold`).update({
      priceRupees: 260,
      updatedAt: pastDate(500),
    })
  );

  await assertSucceeds(claimJorhatPartnerDb.collection("areas").doc(AREA_JORHAT).get());
  await assertFails(claimJorhatPartnerDb.collection("areas").doc(AREA_ZOO).get());
  await assertSucceeds(
    claimJorhatPartnerDb.collection("users").doc(BOB_UID).collection("orders").doc("AKM-5001").update({
      status: "PACKED",
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    claimJorhatPartnerDb.collection("areaPrices").doc(`${AREA_JORHAT}__tea_orthodox_gold`).update({
      priceRupees: 150,
      updatedAt: pastDate(400),
    })
  );
});

