package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LocalShipping
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.OrderRecord
import com.example.model.OrderStatus
import com.example.ui.AxomUiState
import com.example.ui.theme.AxomColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OrdersScreen(
    uiState: AxomUiState,
    bottomContentPadding: Dp,
    onDismissConfirmationBanner: () -> Unit,
    onMarkDelivered: (String) -> Unit,
    onCancelOrder: (String) -> Unit,
    onReorder: (OrderRecord) -> Unit,
    onBrowseProducts: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeOrders = uiState.orders.filter {
        it.status == OrderStatus.CONFIRMED ||
            it.status == OrderStatus.PACKED ||
            it.status == OrderStatus.OUT_FOR_DELIVERY
    }
    val pastOrders = uiState.orders.filter {
        it.status == OrderStatus.DELIVERED || it.status == OrderStatus.CANCELLED
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxomColors.CanvasSlate)
    ) {
        Surface(
            color = AxomColors.CardWhite,
            border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Text(
                    text = "Your Orders",
                    style = MaterialTheme.typography.headlineMedium,
                    color = AxomColors.TextPrimary
                )
                Text(
                    text = "${uiState.orders.size} total orders • Local hub tracking",
                    style = MaterialTheme.typography.bodySmall,
                    color = AxomColors.TextMuted
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 14.dp,
                bottom = bottomContentPadding + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            uiState.lastPlacedOrderId?.let { orderId ->
                item(key = "order_confirm_banner") {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AxomColors.EmeraldSoftBg,
                        border = BorderStroke(1.dp, AxomColors.EmeraldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = AxomColors.ForestSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Order $orderId Confirmed!",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = AxomColors.ForestSecondary
                                )
                                Text(
                                    text = "Packing your local Assam basket now.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AxomColors.TextPrimary
                                )
                            }
                            IconButton(
                                onClick = onDismissConfirmationBanner,
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Dismiss banner",
                                    tint = AxomColors.ForestSecondary
                                )
                            }
                        }
                    }
                }
            }

            if (activeOrders.isNotEmpty()) {
                item(key = "active_header") {
                    Text(
                        text = "Active Delivery",
                        style = MaterialTheme.typography.headlineSmall,
                        color = AxomColors.TextPrimary
                    )
                }
                items(activeOrders, key = { it.orderId }) { order ->
                    ActiveOrderCard(
                        order = order,
                        onMarkDelivered = { onMarkDelivered(order.orderId) },
                        onCancelOrder = { onCancelOrder(order.orderId) }
                    )
                }
            }

            if (pastOrders.isNotEmpty()) {
                item(key = "past_header") {
                    Text(
                        text = "Past Orders",
                        style = MaterialTheme.typography.headlineSmall,
                        color = AxomColors.TextPrimary,
                        modifier = Modifier.padding(top = if (activeOrders.isNotEmpty()) 6.dp else 0.dp)
                    )
                }
                items(pastOrders, key = { it.orderId }) { order ->
                    PastOrderCard(
                        order = order,
                        onReorder = { onReorder(order) }
                    )
                }
            }

            if (uiState.orders.isEmpty()) {
                item(key = "empty_orders") {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AxomColors.CardWhite,
                        border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ReceiptLong,
                                contentDescription = null,
                                tint = AxomColors.EmeraldPrimary,
                                modifier = Modifier.size(42.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No orders placed yet",
                                style = MaterialTheme.typography.titleMedium,
                                color = AxomColors.TextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Your hyperlocal deliveries and quick reorders will appear here.",
                                style = MaterialTheme.typography.bodySmall,
                                color = AxomColors.TextMuted
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onBrowseProducts,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AxomColors.EmeraldPrimary,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Text("Start Shopping")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveOrderCard(
    order: OrderRecord,
    onMarkDelivered: () -> Unit,
    onCancelOrder: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AxomColors.CardWhite,
        border = BorderStroke(1.dp, AxomColors.EmeraldPrimary.copy(alpha = 0.45f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("active_order_${order.orderId}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(AxomColors.EmeraldSoftBg, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LocalShipping,
                            contentDescription = null,
                            tint = AxomColors.ForestSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Order ${order.orderId}",
                            style = MaterialTheme.typography.titleSmall,
                            color = AxomColors.TextPrimary
                        )
                        Text(
                            text = "${order.deliverySlot} • ${order.addressLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = AxomColors.ForestSecondary
                        )
                    }
                }
                Text(
                    text = "₹${order.totalRupees}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFeatureSettings = "tnum"
                    ),
                    color = AxomColors.TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3-step visual delivery progress bar
            val steps = listOf("Confirmed", "Packed", "On the Way", "Delivered")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                steps.forEachIndexed { idx, stepLabel ->
                    val active = idx <= order.status.stepIndex + 1
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .background(
                                    if (active) AxomColors.EmeraldPrimary else AxomColors.SurfaceTintGray,
                                    RoundedCornerShape(9999.dp)
                                )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stepLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (active) AxomColors.ForestSecondary else AxomColors.TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = order.itemsSummary,
                style = MaterialTheme.typography.bodySmall,
                color = AxomColors.TextMuted,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onCancelOrder,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, AxomColors.BorderInput),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                ) {
                    Text("Cancel", color = AxomColors.TextPrimary)
                }
                Button(
                    onClick = onMarkDelivered,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AxomColors.EmeraldPrimary,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(1.4f)
                        .height(44.dp)
                ) {
                    Text("Mark Received")
                }
            }
        }
    }
}

@Composable
private fun PastOrderCard(
    order: OrderRecord,
    onReorder: () -> Unit
) {
    val formattedDate = remember(order.createdAtMillis) {
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(order.createdAtMillis))
    }
    val isCancelled = order.status == OrderStatus.CANCELLED

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = AxomColors.CardWhite,
        border = BorderStroke(1.dp, AxomColors.BorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("past_order_${order.orderId}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${order.orderId} • ${order.addressLabel}",
                        style = MaterialTheme.typography.titleSmall,
                        color = AxomColors.TextPrimary
                    )
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.bodySmall,
                        color = AxomColors.TextMuted
                    )
                }
                Surface(
                    color = if (isCancelled) AxomColors.RedSoftBg else AxomColors.EmeraldSoftBg,
                    shape = RoundedCornerShape(9999.dp)
                ) {
                    Text(
                        text = order.status.label,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = if (isCancelled) AxomColors.RedDiscount else AxomColors.ForestSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = AxomColors.SurfaceTintGray)
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = order.itemsSummary,
                style = MaterialTheme.typography.bodyMedium,
                color = AxomColors.TextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Total Paid (${order.paymentMethod})",
                        style = MaterialTheme.typography.labelSmall,
                        color = AxomColors.TextMuted
                    )
                    Text(
                        text = "₹${order.totalRupees}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFeatureSettings = "tnum"
                        ),
                        color = AxomColors.TextPrimary
                    )
                }

                OutlinedButton(
                    onClick = onReorder,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, AxomColors.EmeraldPrimary),
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("reorder_${order.orderId}")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = null,
                        tint = AxomColors.EmeraldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Reorder",
                        style = MaterialTheme.typography.labelLarge,
                        color = AxomColors.EmeraldPrimary
                    )
                }
            }
        }
    }
}
