package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.ProductCategory
import com.example.ui.AxomUiState
import com.example.ui.CategorySortFilter
import com.example.ui.components.ProductCard
import com.example.ui.components.fallbackIcon
import com.example.ui.components.softTintColor
import com.example.ui.theme.AxomColors

@Composable
fun CategoriesScreen(
    uiState: AxomUiState,
    bottomContentPadding: Dp,
    onSelectCategory: (ProductCategory) -> Unit,
    onSelectSortFilter: (CategorySortFilter) -> Unit,
    onProductClick: (String) -> Unit,
    onIncrementCart: (String) -> Unit,
    onDecrementCart: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val sidebarCategories = ProductCategory.entries.filter { it != ProductCategory.ALL }
    val products = uiState.categoryFilteredProducts

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxomColors.CanvasSlate)
    ) {
        // Header
        Surface(
            color = AxomColors.CardWhite,
            border = BorderStroke(0.5.dp, AxomColors.BorderSubtle)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Shop by Category",
                        style = MaterialTheme.typography.headlineMedium,
                        color = AxomColors.TextPrimary
                    )
                    Text(
                        text = "${uiState.selectedTabCategory.title} • ${products.size} items available",
                        style = MaterialTheme.typography.bodySmall,
                        color = AxomColors.TextMuted
                    )
                }
                Surface(
                    color = AxomColors.EmeraldSoftBg,
                    shape = RoundedCornerShape(9999.dp)
                ) {
                    Text(
                        text = "${uiState.selectedAddress.etaMins} min hub",
                        style = MaterialTheme.typography.labelMedium.copy(fontFeatureSettings = "tnum"),
                        color = AxomColors.ForestSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Split Pane: Left Category Rail + Right Product Grid
        Row(modifier = Modifier.fillMaxSize()) {
            // Left Vertical Category Rail
            Surface(
                color = AxomColors.CardWhite,
                border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
                modifier = Modifier
                    .width(88.dp)
                    .fillMaxHeight()
            ) {
                LazyColumn(
                    contentPadding = PaddingValues(top = 8.dp, bottom = bottomContentPadding + 16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(sidebarCategories, key = { it.id }) { category ->
                        val selected = uiState.selectedTabCategory == category
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 76.dp)
                                .background(
                                    if (selected) AxomColors.EmeraldSoftBg.copy(alpha = 0.55f) else Color.Transparent
                                )
                                .clickable { onSelectCategory(category) }
                                .testTag("cat_rail_${category.id}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(48.dp)
                                    .background(
                                        color = if (selected) AxomColors.EmeraldPrimary else Color.Transparent,
                                        shape = RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp)
                                    )
                            )
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 6.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            if (selected) AxomColors.EmeraldPrimary else category.softTintColor(),
                                            RoundedCornerShape(10.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = category.fallbackIcon(),
                                        contentDescription = category.title,
                                        tint = if (selected) Color.White else AxomColors.ForestSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = category.shortTitle,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                    ),
                                    color = if (selected) AxomColors.ForestSecondary else AxomColors.TextPrimary,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Right Content Area
            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                // Sort / Filter Chips Row
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(CategorySortFilter.entries, key = { it.name }) { filter ->
                        val selected = uiState.categorySortFilter == filter
                        Surface(
                            onClick = { onSelectSortFilter(filter) },
                            shape = RoundedCornerShape(9999.dp),
                            color = if (selected) AxomColors.EmeraldPrimary else AxomColors.CardWhite,
                            border = BorderStroke(
                                1.dp,
                                if (selected) AxomColors.EmeraldPrimary else AxomColors.BorderSubtle
                            ),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Box(
                                modifier = Modifier.padding(horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = filter.label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) Color.White else AxomColors.TextPrimary
                                )
                            }
                        }
                    }
                }

                // Responsive Product Grid
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val columnsCount = when {
                        maxWidth >= 680.dp -> 3
                        maxWidth >= 260.dp -> 2
                        else -> 1
                    }
                    val productRows = products.chunked(columnsCount)

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 12.dp,
                            end = 12.dp,
                            bottom = bottomContentPadding + 16.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (productRows.isEmpty()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = AxomColors.CardWhite,
                                    border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "No items match this filter",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = AxomColors.TextPrimary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Tap 'All' above to see everything in ${uiState.selectedTabCategory.shortTitle}.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = AxomColors.TextMuted,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        } else {
                            items(productRows, key = { row -> row.joinToString("_") { it.id } }) { rowItems ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    for (i in 0 until columnsCount) {
                                        if (i < rowItems.size) {
                                            val product = rowItems[i]
                                            ProductCard(
                                                product = product,
                                                quantity = uiState.cartQuantities[product.id] ?: 0,
                                                isFavorite = uiState.favoriteIds.contains(product.id),
                                                onCardClick = { onProductClick(product.id) },
                                                onIncrement = { onIncrementCart(product.id) },
                                                onDecrement = { onDecrementCart(product.id) },
                                                onToggleFavorite = { onToggleFavorite(product.id) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        } else {
                                            Spacer(modifier = Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
