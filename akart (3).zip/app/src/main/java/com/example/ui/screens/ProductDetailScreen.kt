package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.model.Product
import com.example.ui.AxomUiState
import com.example.ui.components.AddToCartStepper
import com.example.ui.components.ProductCard
import com.example.ui.components.ProductImageBox
import com.example.ui.theme.AxomColors

@Composable
fun ProductDetailScreen(
    product: Product,
    uiState: AxomUiState,
    onBack: () -> Unit,
    onProductClick: (String) -> Unit,
    onIncrementCart: (String) -> Unit,
    onDecrementCart: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onViewCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    val quantity = uiState.cartQuantities[product.id] ?: 0
    val isFavorite = uiState.favoriteIds.contains(product.id)
    val similarProducts = uiState.allProducts.filter {
        it.category == product.category && it.id != product.id
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxomColors.CanvasSlate)
    ) {
        // Top App Bar
        Surface(
            color = AxomColors.CardWhite,
            border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.size(48.dp).testTag("detail_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        tint = AxomColors.TextPrimary
                    )
                }

                Text(
                    text = product.category.shortTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = AxomColors.TextPrimary
                )

                IconButton(
                    onClick = { onToggleFavorite(product.id) },
                    modifier = Modifier.size(48.dp).testTag("detail_fav_button")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Toggle favorite",
                        tint = if (isFavorite) AxomColors.RedDiscount else AxomColors.TextPrimary
                    )
                }
            }
        }

        // Scrollable Content
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                // Hero Image Container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AxomColors.CardWhite)
                        .padding(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1.15f)
                    ) {
                        ProductImageBox(
                            product = product,
                            modifier = Modifier.fillMaxSize()
                        )
                        if (product.discountPercent > 0) {
                            Surface(
                                color = AxomColors.RedDiscount,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "${product.discountPercent}% OFF",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (product.isGiTagged) {
                            Surface(
                                color = AxomColors.ForestSecondary,
                                shape = RoundedCornerShape(9999.dp),
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Verified,
                                        contentDescription = null,
                                        tint = Color(0xFF92F5A4),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "GI-Tagged Assam Origin",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                // Core Details Card
                Surface(
                    color = AxomColors.CardWhite,
                    border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = product.origin,
                                style = MaterialTheme.typography.labelLarge,
                                color = AxomColors.ForestSecondary
                            )
                            Surface(
                                color = AxomColors.AmberSoftBg,
                                shape = RoundedCornerShape(9999.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Star,
                                        contentDescription = null,
                                        tint = AxomColors.AmberRating,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${product.rating} (${product.reviewCount})",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontFeatureSettings = "tnum"
                                        ),
                                        color = AxomColors.TextPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = product.name,
                            style = MaterialTheme.typography.headlineMedium,
                            color = AxomColors.TextPrimary
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Pack size: ${product.unit}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AxomColors.TextMuted
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "₹${product.priceRupees}",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontFeatureSettings = "tnum"
                                ),
                                color = AxomColors.TextPrimary
                            )
                            if (product.mrpRupees > product.priceRupees) {
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "MRP ₹${product.mrpRupees}",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        textDecoration = TextDecoration.LineThrough,
                                        fontFeatureSettings = "tnum"
                                    ),
                                    color = AxomColors.TextMuted
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Fast Local Delivery Strip
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AxomColors.EmeraldSoftBg.copy(alpha = 0.65f),
                            border = BorderStroke(1.dp, AxomColors.EmeraldSoftBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(AxomColors.EmeraldPrimary, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Bolt,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Arrives in ${product.deliveryMins} mins",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = AxomColors.ForestSecondary
                                    )
                                    Text(
                                        text = "Dispatched from ${uiState.selectedAddress.hubName} to ${uiState.selectedAddress.label}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = AxomColors.TextMuted
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = AxomColors.SurfaceTintGray)
                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "About this product",
                            style = MaterialTheme.typography.titleMedium,
                            color = AxomColors.TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = product.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = AxomColors.TextMuted
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        product.highlights.forEach { highlight ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = AxomColors.EmeraldPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = highlight,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AxomColors.TextPrimary
                                )
                            }
                        }
                    }
                }
            }

            if (similarProducts.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(18.dp))
                    Text(
                        text = "More from ${product.category.title}",
                        style = MaterialTheme.typography.headlineSmall,
                        color = AxomColors.TextPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(similarProducts, key = { it.id }) { item ->
                            ProductCard(
                                product = item,
                                quantity = uiState.cartQuantities[item.id] ?: 0,
                                isFavorite = uiState.favoriteIds.contains(item.id),
                                onCardClick = { onProductClick(item.id) },
                                onIncrement = { onIncrementCart(item.id) },
                                onDecrement = { onDecrementCart(item.id) },
                                onToggleFavorite = { onToggleFavorite(item.id) },
                                modifier = Modifier.width(168.dp)
                            )
                        }
                    }
                }
            }
        }

        // Sticky Bottom Purchase Bar
        Surface(
            color = AxomColors.CardWhite,
            border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
            modifier = Modifier
                .fillMaxWidth()
                .shadow(
                    elevation = 6.dp,
                    ambientColor = Color(0x140F172A),
                    spotColor = Color(0x140F172A)
                )
        ) {
            Row(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(modifier = Modifier.weight(0.9f)) {
                    Text(
                        text = "₹${product.priceRupees}",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFeatureSettings = "tnum"
                        ),
                        color = AxomColors.TextPrimary
                    )
                    if (uiState.totalCartCount > 0) {
                        Surface(
                            onClick = onViewCart,
                            color = Color.Transparent
                        ) {
                            Text(
                                text = "View Cart (${uiState.totalCartCount}) →",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = AxomColors.EmeraldPrimary
                            )
                        }
                    } else {
                        Text(
                            text = product.unit,
                            style = MaterialTheme.typography.bodySmall,
                            color = AxomColors.TextMuted
                        )
                    }
                }

                AddToCartStepper(
                    productId = product.id,
                    quantity = quantity,
                    onIncrement = { onIncrementCart(product.id) },
                    onDecrement = { onDecrementCart(product.id) },
                    modifier = Modifier.weight(1.3f)
                )
            }
        }
    }
}
