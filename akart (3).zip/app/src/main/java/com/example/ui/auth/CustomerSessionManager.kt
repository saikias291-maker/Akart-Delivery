package com.example.ui.auth

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class CustomerSession(
    val customerId: String,
    val fullName: String,
    val mobileNumber: String,
    val areaId: String,
    val areaName: String,
    val hubName: String,
    val etaMins: Int,
    val fullAddress: String
)

interface SessionStorage {
    fun readSessionJson(): String?
    fun writeSessionJson(json: String)
    fun clearSession()
}

class EncryptedPrefsSessionStorage(context: Context) : SessionStorage {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    override fun readSessionJson(): String? {
        val encoded = prefs.getString(KEY_ENCRYPTED_SESSION, null) ?: return null
        return try {
            val combined = Base64.decode(encoded, Base64.NO_WRAP)
            if (combined.size <= GCM_IV_LENGTH) return null
            val iv = combined.copyOfRange(0, GCM_IV_LENGTH)
            val cipherText = combined.copyOfRange(GCM_IV_LENGTH, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(GCM_TAG_BITS, iv))
            String(cipher.doFinal(cipherText), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.w(TAG, "Unable to decrypt stored session, clearing", e)
            clearSession()
            null
        }
    }

    override fun writeSessionJson(json: String) {
        try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
            val iv = cipher.iv
            val encrypted = cipher.doFinal(json.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(iv.size + encrypted.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(encrypted, 0, combined, iv.size, encrypted.size)
            val encoded = Base64.encodeToString(combined, Base64.NO_WRAP)
            prefs.edit().putString(KEY_ENCRYPTED_SESSION, encoded).apply()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to encrypt customer session", e)
            throw IllegalStateException("Secure session storage unavailable", e)
        }
    }

    override fun clearSession() {
        prefs.edit().remove(KEY_ENCRYPTED_SESSION).apply()
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private companion object {
        const val TAG = "CustomerSessionStorage"
        const val PREFS_NAME = "akart_secure_customer_session"
        const val KEY_ENCRYPTED_SESSION = "encrypted_session_v1"
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val KEY_ALIAS = "akart_customer_session_aes_key"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val GCM_IV_LENGTH = 12
        const val GCM_TAG_BITS = 128
    }
}

class CustomerSessionManager(
    private val storage: SessionStorage
) {
    constructor(context: Context) : this(EncryptedPrefsSessionStorage(context))

    private val _sessionFlow = MutableStateFlow(loadStoredSession())
    val sessionFlow: StateFlow<CustomerSession?> = _sessionFlow.asStateFlow()

    private fun loadStoredSession(): CustomerSession? {
        val raw = storage.readSessionJson() ?: return null
        return try {
            val obj = JSONObject(raw)
            val customerId = obj.optString("customerId").trim()
            val fullName = obj.optString("fullName").trim()
            val mobileNumber = obj.optString("mobileNumber").trim()
            val areaId = obj.optString("areaId").trim()
            val areaName = obj.optString("areaName").trim()
            val hubName = obj.optString("hubName").trim()
            val etaMins = obj.optInt("etaMins", 15).coerceIn(1, 120)
            val fullAddress = obj.optString("fullAddress").trim()
            if (customerId.isBlank() || areaId.isBlank() || mobileNumber.length != 10) {
                storage.clearSession()
                null
            } else {
                CustomerSession(
                    customerId = customerId,
                    fullName = fullName,
                    mobileNumber = mobileNumber,
                    areaId = areaId,
                    areaName = areaName,
                    hubName = hubName,
                    etaMins = etaMins,
                    fullAddress = fullAddress
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Corrupted session payload, clearing", e)
            storage.clearSession()
            null
        }
    }

    fun saveSession(session: CustomerSession) {
        val json = JSONObject().apply {
            put("customerId", session.customerId)
            put("fullName", session.fullName)
            put("mobileNumber", session.mobileNumber)
            put("areaId", session.areaId)
            put("areaName", session.areaName)
            put("hubName", session.hubName)
            put("etaMins", session.etaMins)
            put("fullAddress", session.fullAddress)
        }.toString()
        storage.writeSessionJson(json)
        _sessionFlow.value = session
    }

    fun clearSession() {
        storage.clearSession()
        _sessionFlow.value = null
    }

    private companion object {
        const val TAG = "CustomerSessionManager"
    }
}
