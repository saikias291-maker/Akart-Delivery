package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.BakeryDining
import androidx.compose.material.icons.rounded.Checkroom
import androidx.compose.material.icons.rounded.Cookie
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.RiceBowl
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.model.Product
import com.example.model.ProductCategory
import com.example.ui.theme.AxomColors

fun ProductCategory.fallbackIcon(): ImageVector = when (this) {
    ProductCategory.TEA_BREWS -> Icons.Rounded.LocalCafe
    ProductCategory.FRESH_PRODUCE -> Icons.Rounded.Eco
    ProductCategory.RICE_STAPLES -> Icons.Rounded.RiceBowl
    ProductCategory.DAIRY_BAKERY -> Icons.Rounded.BakeryDining
    ProductCategory.SNACKS_SWEETS -> Icons.Rounded.Cookie
    ProductCategory.LOCAL_CRAFTS -> Icons.Rounded.Checkroom
    ProductCategory.ALL -> Icons.Rounded.ShoppingBag
}

fun ProductCategory.softTintColor(): Color = when (this) {
    ProductCategory.TEA_BREWS -> Color(0xFFE8F5E9)
    ProductCategory.FRESH_PRODUCE -> Color(0xFFECFDF5)
    ProductCategory.RICE_STAPLES -> Color(0xFFFEF9C3)
    ProductCategory.DAIRY_BAKERY -> Color(0xFFEFF6FF)
    ProductCategory.SNACKS_SWEETS -> Color(0xFFFFF7ED)
    ProductCategory.LOCAL_CRAFTS -> Color(0xFFFDF2F8)
    ProductCategory.ALL -> Color(0xFFF1F5F9)
}

@Composable
fun ProductImageBox(
    product: Product,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Box(
        modifier = modifier
            .background(AxomColors.CanvasSlate, RoundedCornerShape(8.dp))
            .clip(RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        SubcomposeAsyncImage(
            model = ImageRequest.Builder(context)
                .data(product.imageUrl)
                .crossfade(true)
                .build(),
            contentDescription = product.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
            loading = {
                CategoryFallbackGraphic(category = product.category)
            },
            error = {
                CategoryFallbackGraphic(category = product.category)
            }
        )
    }
}

@Composable
private fun CategoryFallbackGraphic(category: ProductCategory) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(category.softTintColor()),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = category.fallbackIcon(),
            contentDescription = null,
            tint = AxomColors.EmeraldPrimary.copy(alpha = 0.72f),
            modifier = Modifier.size(42.dp)
        )
    }
}

@Composable
fun ProductCard(
    product: Product,
    quantity: Int,
    isFavorite: Boolean,
    onCardClick: () -> Unit,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}")
            .clickable(onClick = onCardClick),
        shape = RoundedCornerShape(8.dp),
        color = AxomColors.CardWhite,
        border = BorderStroke(1.dp, AxomColors.BorderSubtle)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
            ) {
                ProductImageBox(
                    product = product,
                    modifier = Modifier.fillMaxSize()
                )

                // Top-left Discount or GI Tag
                if (product.discountPercent > 0) {
                    Surface(
                        color = AxomColors.RedDiscount,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                    ) {
                        Text(
                            text = "${product.discountPercent}% OFF",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                } else if (product.isGiTagged) {
                    Surface(
                        color = AxomColors.ForestSecondary,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                    ) {
                        Text(
                            text = "GI ASSAM",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                // Top-right Favorite Toggle (48dp touch target)
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(48.dp)
                        .testTag("fav_button_${product.id}")
                ) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .background(Color.White.copy(alpha = 0.92f), CircleShape)
                            .border(0.5.dp, AxomColors.BorderSubtle, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                            tint = if (isFavorite) AxomColors.RedDiscount else AxomColors.TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Bottom-left Delivery Time Pill
                Surface(
                    color = Color.White.copy(alpha = 0.94f),
                    shape = RoundedCornerShape(9999.dp),
                    border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${product.deliveryMins}m",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                fontFeatureSettings = "tnum"
                            ),
                            color = AxomColors.ForestSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Origin & Rating Micro Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (product.isGiTagged) {
                        Icon(
                            imageVector = Icons.Rounded.Verified,
                            contentDescription = "GI Certified",
                            tint = AxomColors.EmeraldPrimary,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                    }
                    Text(
                        text = product.origin,
                        style = MaterialTheme.typography.labelSmall,
                        color = AxomColors.TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Star,
                        contentDescription = null,
                        tint = AxomColors.AmberRating,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "${product.rating}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontFeatureSettings = "tnum"
                        ),
                        color = AxomColors.TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // 2-line max product title
            Text(
                text = product.name,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = AxomColors.TextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.heightIn(min = 40.dp)
            )

            Spacer(modifier = Modifier.height(2.dp))

            // Unit / Weight
            Text(
                text = product.unit,
                style = MaterialTheme.typography.bodySmall,
                color = AxomColors.TextMuted,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Price Row + MRP
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "₹${product.priceRupees}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontFeatureSettings = "tnum"
                    ),
                    color = AxomColors.TextPrimary
                )
                if (product.mrpRupees > product.priceRupees) {
                    Text(
                        text = "₹${product.mrpRupees}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            textDecoration = TextDecoration.LineThrough,
                            fontFeatureSettings = "tnum"
                        ),
                        color = AxomColors.TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Full-width Add Button / Stepper
            AddToCartStepper(
                productId = product.id,
                quantity = quantity,
                onIncrement = onIncrement,
                onDecrement = onDecrement,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun AddToCartStepper(
    productId: String,
    quantity: Int,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val controlHeight = if (compact) 40.dp else 48.dp
    AnimatedContent(
        targetState = quantity > 0,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "add_stepper_$productId",
        modifier = modifier
    ) { inCart ->
        if (!inCart) {
            Surface(
                onClick = onIncrement,
                shape = RoundedCornerShape(8.dp),
                color = AxomColors.CardWhite,
                border = BorderStroke(1.dp, AxomColors.EmeraldPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(controlHeight)
                    .minimumInteractiveComponentSize()
                    .testTag("add_button_$productId")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "ADD",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = AxomColors.EmeraldPrimary
                    )
                }
            }
        } else {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = AxomColors.EmeraldPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(controlHeight)
                    .testTag("stepper_$productId")
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 48.dp, height = controlHeight)
                            .clickable(onClick = onDecrement)
                            .testTag("decrement_$productId"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Remove,
                            contentDescription = "Decrease quantity",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = "$quantity",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFeatureSettings = "tnum"
                        ),
                        color = Color.White
                    )
                    Box(
                        modifier = Modifier
                            .size(width = 48.dp, height = controlHeight)
                            .clickable(onClick = onIncrement)
                            .testTag("increment_$productId"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Increase quantity",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StickyCartSummaryBar(
    itemCount: Int,
    totalRupees: Int,
    savingsRupees: Int,
    onViewCartClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onViewCartClick,
        shape = RoundedCornerShape(12.dp),
        color = AxomColors.ForestSecondary,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(12.dp),
                ambientColor = Color(0x140F172A),
                spotColor = Color(0x140F172A)
            )
            .testTag("sticky_cart_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.White.copy(alpha = 0.16f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ShoppingBag,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    val itemLabel = if (itemCount == 1) "1 item" else "$itemCount items"
                    Text(
                        text = "$itemLabel  •  ₹$totalRupees",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFeatureSettings = "tnum"
                        ),
                        color = Color.White
                    )
                    if (savingsRupees > 0) {
                        Text(
                            text = "Saving ₹$savingsRupees on this basket",
                            style = MaterialTheme.typography.labelSmall.copy(fontFeatureSettings = "tnum"),
                            color = Color(0xFFBBF7D0)
                        )
                    } else {
                        Text(
                            text = "Local hub express dispatch",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFBBF7D0)
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "View Cart",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
