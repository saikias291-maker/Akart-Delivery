package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CatalogData
import com.example.data.remote.AreaPriceDoc
import com.example.data.remote.AxomDataRepository
import com.example.data.remote.CartItemDoc
import com.example.data.remote.FirestoreRepository
import com.example.model.CartLineItem
import com.example.model.DeliveryAddress
import com.example.model.DeliverySlot
import com.example.model.OrderRecord
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.Product
import com.example.model.ProductCategory
import com.example.model.PromoOffer
import com.example.model.UserPreferences
import com.example.ui.auth.CustomerSession
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class CategorySortFilter(val label: String) {
    ALL("All"),
    UNDER_100("Under ₹100"),
    GI_TAGGED("GI-Tagged"),
    TOP_RATED("4.8★ & Up")
}

data class AxomUiState(
    val customerId: String = "",
    val registeredAreaId: String = "",
    val searchQuery: String = "",
    val selectedHomeCategory: ProductCategory = ProductCategory.ALL,
    val selectedTabCategory: ProductCategory = ProductCategory.TEA_BREWS,
    val categorySortFilter: CategorySortFilter = CategorySortFilter.ALL,
    val allProducts: List<Product> = emptyList(),
    val cartItems: List<CartLineItem> = emptyList(),
    val cartQuantities: Map<String, Int> = emptyMap(),
    val addresses: List<DeliveryAddress> = emptyList(),
    val selectedAddress: DeliveryAddress = DeliveryAddress(
        label = "Home",
        area = "",
        fullAddress = "",
        pinCode = "",
        hubName = "",
        etaMins = 12,
        isSelected = true
    ),
    val orders: List<OrderRecord> = emptyList(),
    val favoriteIds: Set<String> = emptySet(),
    val selectedSlot: DeliverySlot = DeliverySlot.EXPRESS,
    val selectedPayment: PaymentMethod = PaymentMethod.UPI,
    val appliedPromoCode: String? = null,
    val promoMessage: String? = null,
    val userPreferences: UserPreferences = UserPreferences(),
    val lastPlacedOrderId: String? = null,
    val showFavoritesOnly: Boolean = false,
    val errorMessage: String? = null
) {
    val totalCartCount: Int
        get() = cartItems.sumOf { it.quantity }

    val cartSubtotalRupees: Int
        get() = cartItems.sumOf { it.lineTotalRupees }

    val cartMrpTotalRupees: Int
        get() = cartItems.sumOf { it.lineMrpTotalRupees }

    val itemSavingsRupees: Int
        get() = (cartMrpTotalRupees - cartSubtotalRupees).coerceAtLeast(0)

    val deliveryFeeRupees: Int
        get() = if (cartSubtotalRupees == 0 || cartSubtotalRupees >= 199) 0 else 25

    val freeDeliveryThresholdRemaining: Int
        get() = (199 - cartSubtotalRupees).coerceAtLeast(0)

    val appliedPromoOffer: PromoOffer?
        get() = appliedPromoCode?.let { code ->
            CatalogData.promoOffers.firstOrNull { it.code.equals(code, ignoreCase = true) }
        }

    val promoDiscountRupees: Int
        get() = appliedPromoOffer?.computeDiscount(cartSubtotalRupees) ?: 0

    val grandTotalRupees: Int
        get() = (cartSubtotalRupees + deliveryFeeRupees - promoDiscountRupees).coerceAtLeast(0)

    val homeFilteredProducts: List<Product>
        get() {
            val query = searchQuery.trim()
            return allProducts.filter { product ->
                val matchesCategory = selectedHomeCategory == ProductCategory.ALL ||
                    product.category == selectedHomeCategory
                val matchesQuery = query.isEmpty() ||
                    product.name.contains(query, ignoreCase = true) ||
                    product.origin.contains(query, ignoreCase = true) ||
                    product.category.title.contains(query, ignoreCase = true)
                val matchesFav = !showFavoritesOnly || favoriteIds.contains(product.id)
                matchesCategory && matchesQuery && matchesFav
            }
        }

    val categoryFilteredProducts: List<Product>
        get() {
            val byCategory = if (selectedTabCategory == ProductCategory.ALL) {
                allProducts
            } else {
                allProducts.filter { it.category == selectedTabCategory }
            }
            return when (categorySortFilter) {
                CategorySortFilter.ALL -> byCategory
                CategorySortFilter.UNDER_100 -> byCategory.filter { it.priceRupees < 100 }
                CategorySortFilter.GI_TAGGED -> byCategory.filter { it.isGiTagged }
                CategorySortFilter.TOP_RATED -> byCategory.filter { it.rating >= 4.8 }
            }
        }
}

private data class LocalUiFilterState(
    val searchQuery: String = "",
    val selectedHomeCategory: ProductCategory = ProductCategory.ALL,
    val selectedTabCategory: ProductCategory = ProductCategory.TEA_BREWS,
    val categorySortFilter: CategorySortFilter = CategorySortFilter.ALL,
    val selectedSlot: DeliverySlot = DeliverySlot.EXPRESS,
    val selectedPayment: PaymentMethod = PaymentMethod.UPI,
    val appliedPromoCode: String? = null,
    val promoMessage: String? = null,
    val lastPlacedOrderId: String? = null,
    val showFavoritesOnly: Boolean = false,
    val mutationError: String? = null
)

private sealed interface StreamOutcome<out T> {
    data class Value<T>(val data: T) : StreamOutcome<T>
    data class Error(val message: String) : StreamOutcome<Nothing>
}

@OptIn(ExperimentalCoroutinesApi::class)
class AxomViewModel(
    private val repository: AxomDataRepository,
    private val session: CustomerSession
) : ViewModel() {

    private val currentUserId: String = session.customerId
    private val registeredAreaId: String = session.areaId

    private val sessionFallbackAddress = DeliveryAddress(
        id = 1L,
        docId = "addr_primary",
        areaId = session.areaId,
        label = "Home",
        area = session.areaName,
        fullAddress = session.fullAddress,
        pinCode = CatalogData.defaultServiceAreas
            .firstOrNull { it.areaId == session.areaId }
            ?.pinCodes?.firstOrNull() ?: "781001",
        hubName = session.hubName,
        etaMins = session.etaMins,
        isSelected = true
    )

    private val filterState = MutableStateFlow(LocalUiFilterState())

    private fun <T> Flow<T>.toSafeOutcome(
        label: String
    ): Flow<StreamOutcome<T>> =
        this.map<T, StreamOutcome<T>> { StreamOutcome.Value(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing $label", rootError)
                emit(StreamOutcome.Error(rootError.message ?: "Failed to load $label"))
            }

    private val catalogSnapshotFlow = combine(
        repository.observeProducts(currentUserId).toSafeOutcome("products"),
        repository.observeAreaPrices(currentUserId, registeredAreaId).toSafeOutcome("areaPrices"),
        repository.observeHasAnyAreaPrices().toSafeOutcome("areaPricesCheck")
    ) { productsOut, pricesOut, hasAnyPricesOut ->
        val errors = listOfNotNull(
            (productsOut as? StreamOutcome.Error)?.message,
            (pricesOut as? StreamOutcome.Error)?.message
        )
        CatalogSnapshot(
            baseProducts = (productsOut as? StreamOutcome.Value)?.data ?: CatalogData.products,
            areaPrices = (pricesOut as? StreamOutcome.Value)?.data ?: emptyMap(),
            hasAnyAreaPricesInDb = (hasAnyPricesOut as? StreamOutcome.Value)?.data ?: false,
            errorMessage = errors.firstOrNull()
        )
    }

    private val userSnapshotFlow = combine(
        repository.observeRawCartItems(currentUserId).toSafeOutcome("cart"),
        repository.observeAddresses(currentUserId).toSafeOutcome("addresses"),
        repository.observeOrders(currentUserId).toSafeOutcome("orders"),
        repository.observeFavoriteIds(currentUserId).toSafeOutcome("favorites"),
        repository.observeUserPreferences(currentUserId).toSafeOutcome("profile")
    ) { cartOut, addrOut, ordersOut, favOut, prefsOut ->
        val errors = listOfNotNull(
            (cartOut as? StreamOutcome.Error)?.message,
            (addrOut as? StreamOutcome.Error)?.message,
            (ordersOut as? StreamOutcome.Error)?.message,
            (favOut as? StreamOutcome.Error)?.message,
            (prefsOut as? StreamOutcome.Error)?.message
        )
        val rawPrefs = (prefsOut as? StreamOutcome.Value)?.data
        val resolvedPrefs = if (rawPrefs != null && rawPrefs.shopperName.isNotBlank()) {
            rawPrefs.copy(primaryAreaId = rawPrefs.primaryAreaId.ifBlank { registeredAreaId })
        } else {
            UserPreferences(
                shopperName = session.fullName,
                shopperPhone = session.mobileNumber,
                primaryAreaId = registeredAreaId
            )
        }
        UserSnapshot(
            rawCartItems = (cartOut as? StreamOutcome.Value)?.data ?: emptyList(),
            addresses = (addrOut as? StreamOutcome.Value)?.data ?: emptyList(),
            orders = (ordersOut as? StreamOutcome.Value)?.data ?: emptyList(),
            favoriteIds = (favOut as? StreamOutcome.Value)?.data ?: emptySet(),
            userPreferences = resolvedPrefs,
            errorMessage = errors.firstOrNull()
        )
    }

    private val persistedDataFlow = combine(
        catalogSnapshotFlow,
        userSnapshotFlow
    ) { catalogSnap, userSnap ->
        val areaPrices = catalogSnap.areaPrices
        val strictAreaFilter = areaPrices.isNotEmpty() || catalogSnap.hasAnyAreaPricesInDb

        val areaAppliedProducts = catalogSnap.baseProducts.map { product ->
            val areaPrice = areaPrices[product.id]
            when {
                areaPrice != null -> {
                    val resolvedPrice = areaPrice.priceRupees.toInt().coerceAtLeast(1)
                    val resolvedMrp = areaPrice.mrpRupees.toInt().coerceAtLeast(resolvedPrice)
                    val resolvedEta = areaPrice.deliveryMins.toInt().coerceAtLeast(5)
                    product.copy(
                        priceRupees = resolvedPrice,
                        mrpRupees = resolvedMrp,
                        deliveryMins = resolvedEta,
                        isAvailableInArea = areaPrice.available
                    )
                }
                strictAreaFilter -> product.copy(isAvailableInArea = false)
                else -> product.copy(deliveryMins = session.etaMins.coerceAtLeast(5))
            }
        }
        val availableProducts = areaAppliedProducts.filter { it.isAvailableInArea }
        val productLookup = areaAppliedProducts.associateBy { it.id }

        val hydratedCartItems = userSnap.rawCartItems.mapNotNull { doc ->
            val product = productLookup[doc.productId]
                ?.takeIf { it.isAvailableInArea }
                ?: if (!strictAreaFilter) CatalogData.findById(doc.productId) else null
            val qty = doc.quantity.toInt()
            if (product != null && qty > 0) {
                CartLineItem(product = product, quantity = qty)
            } else {
                null
            }
        }

        // Only keep addresses matching the customer's permanent registered area
        val areaLockedAddresses = userSnap.addresses.filter {
            it.areaId.isBlank() || it.areaId == registeredAreaId
        }

        PersistedSnapshot(
            products = availableProducts,
            cartItems = hydratedCartItems,
            addresses = areaLockedAddresses.ifEmpty { listOf(sessionFallbackAddress) },
            orders = userSnap.orders,
            favoriteIds = userSnap.favoriteIds,
            userPreferences = userSnap.userPreferences,
            streamError = userSnap.errorMessage ?: catalogSnap.streamError
        )
    }

    val uiState: StateFlow<AxomUiState> = combine(
        filterState,
        persistedDataFlow
    ) { local, persisted ->
        val selectedAddress = persisted.addresses.firstOrNull { it.isSelected }
            ?: persisted.addresses.firstOrNull()
            ?: sessionFallbackAddress
        AxomUiState(
            customerId = currentUserId,
            registeredAreaId = registeredAreaId,
            searchQuery = local.searchQuery,
            selectedHomeCategory = local.selectedHomeCategory,
            selectedTabCategory = local.selectedTabCategory,
            categorySortFilter = local.categorySortFilter,
            allProducts = persisted.products,
            cartItems = persisted.cartItems,
            cartQuantities = persisted.cartItems.associate { it.product.id to it.quantity },
            addresses = persisted.addresses,
            selectedAddress = selectedAddress.copy(areaId = registeredAreaId),
            orders = persisted.orders,
            favoriteIds = persisted.favoriteIds,
            selectedSlot = local.selectedSlot,
            selectedPayment = local.selectedPayment,
            appliedPromoCode = local.appliedPromoCode,
            promoMessage = local.promoMessage,
            userPreferences = persisted.userPreferences,
            lastPlacedOrderId = local.lastPlacedOrderId,
            showFavoritesOnly = local.showFavoritesOnly,
            errorMessage = local.mutationError ?: persisted.streamError
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = AxomUiState(
            customerId = currentUserId,
            registeredAreaId = registeredAreaId,
            selectedAddress = sessionFallbackAddress,
            userPreferences = UserPreferences(
                shopperName = session.fullName,
                shopperPhone = session.mobileNumber,
                primaryAreaId = registeredAreaId
            )
        )
    )

    fun dismissError() {
        filterState.update { it.copy(mutationError = null) }
    }

    fun updateSearchQuery(query: String) {
        filterState.update { it.copy(searchQuery = query) }
    }

    fun selectHomeCategory(category: ProductCategory) {
        filterState.update { it.copy(selectedHomeCategory = category) }
    }

    fun selectTabCategory(category: ProductCategory) {
        filterState.update { it.copy(selectedTabCategory = category) }
    }

    fun selectCategorySortFilter(filter: CategorySortFilter) {
        filterState.update { it.copy(categorySortFilter = filter) }
    }

    fun toggleFavoritesFilter() {
        filterState.update { it.copy(showFavoritesOnly = !it.showFavoritesOnly) }
    }

    fun incrementCart(productId: String) {
        val current = uiState.value.cartQuantities[productId] ?: 0
        viewModelScope.launch {
            repository.setCartQuantity(productId, current + 1)
                .onFailure { recordMutationError(it) }
        }
    }

    fun decrementCart(productId: String) {
        val current = uiState.value.cartQuantities[productId] ?: 0
        viewModelScope.launch {
            repository.setCartQuantity(productId, (current - 1).coerceAtLeast(0))
                .onFailure { recordMutationError(it) }
        }
    }

    fun toggleFavorite(productId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(productId)
                .onFailure { recordMutationError(it) }
        }
    }

    fun selectAddress(addressDocId: String) {
        if (addressDocId.isBlank()) return
        viewModelScope.launch {
            repository.selectAddress(addressDocId)
                .onFailure { recordMutationError(it) }
        }
    }

    fun addAddressInRegisteredArea(label: String, fullAddress: String) {
        val cleanLabel = label.trim()
        val cleanAddress = fullAddress.trim()
        if (cleanLabel.isBlank() || cleanAddress.length < 5) {
            filterState.update { it.copy(mutationError = "Please enter a full street address (at least 5 characters).") }
            return
        }
        viewModelScope.launch {
            repository.addAddressInRegisteredArea(
                label = cleanLabel,
                fullAddress = cleanAddress,
                registeredAddress = uiState.value.selectedAddress.copy(areaId = registeredAreaId)
            ).onFailure { recordMutationError(it) }
        }
    }

    fun selectDeliverySlot(slot: DeliverySlot) {
        filterState.update { it.copy(selectedSlot = slot) }
    }

    fun selectPaymentMethod(method: PaymentMethod) {
        filterState.update { it.copy(selectedPayment = method) }
    }

    fun applyPromoCode(rawCode: String) {
        val code = rawCode.trim().uppercase()
        if (code.isEmpty()) {
            filterState.update { it.copy(appliedPromoCode = null, promoMessage = null) }
            return
        }
        val offer = CatalogData.promoOffers.firstOrNull { it.code.equals(code, ignoreCase = true) }
        if (offer == null) {
            filterState.update { it.copy(promoMessage = "Invalid code. Try AXOM10, BIHU50, or FRESH20.") }
            return
        }
        val subtotal = uiState.value.cartSubtotalRupees
        if (subtotal < offer.minOrderRupees) {
            filterState.update {
                it.copy(
                    appliedPromoCode = code,
                    promoMessage = "Add ₹${offer.minOrderRupees - subtotal} more to unlock ${offer.code}"
                )
            }
        } else {
            filterState.update {
                it.copy(
                    appliedPromoCode = code,
                    promoMessage = "${offer.code} applied! Saving ₹${offer.computeDiscount(subtotal)}"
                )
            }
        }
    }

    fun clearPromoCode() {
        filterState.update { it.copy(appliedPromoCode = null, promoMessage = null) }
    }

    fun placeOrder(onOrderCreated: (String) -> Unit) {
        val state = uiState.value
        if (state.cartItems.isEmpty()) return
        viewModelScope.launch {
            repository.placeOrder(
                items = state.cartItems,
                address = state.selectedAddress.copy(areaId = registeredAreaId),
                slot = state.selectedSlot,
                paymentMethod = state.selectedPayment,
                subtotal = state.cartSubtotalRupees,
                deliveryFee = state.deliveryFeeRupees,
                discount = state.promoDiscountRupees,
                total = state.grandTotalRupees
            ).onSuccess { orderId ->
                filterState.update {
                    it.copy(
                        appliedPromoCode = null,
                        promoMessage = null,
                        lastPlacedOrderId = orderId
                    )
                }
                onOrderCreated(orderId)
            }.onFailure {
                recordMutationError(it)
            }
        }
    }

    fun clearLastPlacedOrderBanner() {
        filterState.update { it.copy(lastPlacedOrderId = null) }
    }

    fun markOrderDelivered(orderId: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, OrderStatus.DELIVERED)
                .onFailure { recordMutationError(it) }
        }
    }

    fun cancelOrder(orderId: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, OrderStatus.CANCELLED)
                .onFailure { recordMutationError(it) }
        }
    }

    fun reorder(order: OrderRecord, onReady: () -> Unit) {
        val validIds = uiState.value.allProducts.map { it.id }.toSet()
        viewModelScope.launch {
            repository.reorderItems(order, validProductIds = validIds)
                .onSuccess { onReady() }
                .onFailure { recordMutationError(it) }
        }
    }

    fun updateProfile(name: String, phone: String) {
        val cleanName = name.trim()
        val cleanPhone = phone.trim()
        if (cleanName.length < 2) {
            filterState.update { it.copy(mutationError = "Full name must be at least 2 characters.") }
            return
        }
        if (!cleanPhone.matches(FirestoreRepository.MOBILE_REGEX)) {
            filterState.update { it.copy(mutationError = "Mobile number must be exactly 10 digits.") }
            return
        }
        viewModelScope.launch {
            repository.updateProfile(cleanName, cleanPhone)
                .onFailure { recordMutationError(it) }
        }
    }

    fun setLeaveAtDoor(enabled: Boolean) {
        viewModelScope.launch {
            repository.setLeaveAtDoor(enabled)
                .onFailure { recordMutationError(it) }
        }
    }

    fun setEcoClothBag(enabled: Boolean) {
        viewModelScope.launch {
            repository.setEcoClothBag(enabled)
                .onFailure { recordMutationError(it) }
        }
    }

    private fun recordMutationError(error: Throwable) {
        filterState.update {
            it.copy(mutationError = error.localizedMessage ?: "Unable to sync change to cloud")
        }
    }

    private data class CatalogSnapshot(
        val baseProducts: List<Product>,
        val areaPrices: Map<String, AreaPriceDoc>,
        val hasAnyAreaPricesInDb: Boolean,
        val errorMessage: String?
    )

    private data class UserSnapshot(
        val rawCartItems: List<CartItemDoc>,
        val addresses: List<DeliveryAddress>,
        val orders: List<OrderRecord>,
        val favoriteIds: Set<String>,
        val userPreferences: UserPreferences,
        val errorMessage: String?
    )

    private data class PersistedSnapshot(
        val products: List<Product>,
        val cartItems: List<CartLineItem>,
        val addresses: List<DeliveryAddress>,
        val orders: List<OrderRecord>,
        val favoriteIds: Set<String>,
        val userPreferences: UserPreferences,
        val streamError: String?
    )

    private companion object {
        const val TAG = "AxomViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
