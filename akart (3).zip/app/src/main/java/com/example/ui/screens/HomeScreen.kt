package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.Product
import com.example.model.ProductCategory
import com.example.ui.AxomUiState
import com.example.ui.components.ProductCard
import com.example.ui.components.fallbackIcon
import com.example.ui.theme.AxomColors
import com.example.ui.theme.AxomMartTheme

@Composable
fun HomeScreen(
    uiState: AxomUiState,
    bottomContentPadding: Dp,
    onSearchQueryChange: (String) -> Unit,
    onSelectCategory: (ProductCategory) -> Unit,
    onToggleFavoritesOnly: () -> Unit,
    onProductClick: (String) -> Unit,
    onIncrementCart: (String) -> Unit,
    onDecrementCart: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onExploreDealsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val featuredDeals = uiState.allProducts.filter { it.isFeaturedDeal }
    val filteredProducts = uiState.homeFilteredProducts

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxomColors.CanvasSlate)
    ) {
        // Crisp White Top Header + Search Bar
        Surface(
            color = AxomColors.CardWhite,
            border = BorderStroke(0.5.dp, AxomColors.BorderSubtle)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Fixed Registered Delivery Area Header (no area switching on home screen)
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("registered_area_header"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(AxomColors.EmeraldSoftBg, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.LocationOn,
                                contentDescription = "Registered delivery area",
                                tint = AxomColors.EmeraldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.Bolt,
                                    contentDescription = null,
                                    tint = AxomColors.ForestSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "Delivering in ${uiState.selectedAddress.etaMins} mins",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontFeatureSettings = "tnum"
                                    ),
                                    color = AxomColors.ForestSecondary
                                )
                            }
                            Text(
                                text = uiState.selectedAddress.area.ifBlank { uiState.selectedAddress.label },
                                style = MaterialTheme.typography.titleSmall,
                                color = AxomColors.TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Saved Favorites Filter Toggle
                    IconButton(
                        onClick = onToggleFavoritesOnly,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("home_favorites_toggle")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    if (uiState.showFavoritesOnly) AxomColors.RedSoftBg else AxomColors.SurfaceTintGray,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (uiState.showFavoritesOnly) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "Filter saved favorites",
                                tint = if (uiState.showFavoritesOnly) AxomColors.RedDiscount else AxomColors.TextPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 48dp Search Bar
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AxomColors.SurfaceTintGray,
                    border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search",
                            tint = AxomColors.TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                            if (uiState.searchQuery.isEmpty()) {
                                Text(
                                    text = "Search Assam tea, Joha rice, Kaji Nemu…",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AxomColors.TextMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            BasicTextField(
                                value = uiState.searchQuery,
                                onValueChange = onSearchQueryChange,
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodyMedium.copy(
                                    color = AxomColors.TextPrimary
                                ),
                                cursorBrush = SolidColor(AxomColors.EmeraldPrimary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("home_search_input")
                            )
                        }
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { onSearchQueryChange("") },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Clear search",
                                    tint = AxomColors.TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Scrollable Feed
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val columnsCount = when {
                maxWidth >= 900.dp -> 4
                maxWidth >= 600.dp -> 3
                else -> 2
            }
            val outerMargin = if (maxWidth >= 600.dp) 24.dp else 16.dp
            val gutter = if (maxWidth >= 600.dp) 16.dp else 12.dp

            val productRows = filteredProducts.chunked(columnsCount)

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = bottomContentPadding + 16.dp)
            ) {
                // Hero Banner (shown when not actively searching or filtering favorites)
                if (uiState.searchQuery.isBlank() && !uiState.showFavoritesOnly) {
                    item(key = "hero_banner") {
                        AssamHeroBanner(
                            hubName = uiState.selectedAddress.hubName,
                            onExploreClick = onExploreDealsClick,
                            modifier = Modifier.padding(horizontal = outerMargin, vertical = 14.dp)
                        )
                    }
                } else {
                    item(key = "top_spacer") {
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }

                // Category Filter Pills
                item(key = "category_chips") {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = outerMargin),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(ProductCategory.entries, key = { it.id }) { category ->
                            val selected = uiState.selectedHomeCategory == category
                            Surface(
                                onClick = { onSelectCategory(category) },
                                shape = RoundedCornerShape(9999.dp),
                                color = if (selected) AxomColors.EmeraldPrimary else AxomColors.SurfaceTintGray,
                                border = if (selected) null else BorderStroke(1.dp, AxomColors.BorderSubtle),
                                modifier = Modifier
                                    .heightIn(min = 36.dp)
                                    .testTag("home_chip_${category.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = category.fallbackIcon(),
                                        contentDescription = null,
                                        tint = if (selected) Color.White else AxomColors.ForestSecondary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = category.shortTitle,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (selected) Color.White else AxomColors.TextPrimary
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Featured Assam Specials Horizontal Carousel
                if (uiState.searchQuery.isBlank() &&
                    uiState.selectedHomeCategory == ProductCategory.ALL &&
                    !uiState.showFavoritesOnly
                ) {
                    item(key = "featured_header") {
                        SectionHeaderRow(
                            title = "Assam Heritage Specials",
                            subtitle = "GI-tagged harvests & daily fresh picks",
                            modifier = Modifier.padding(horizontal = outerMargin)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                    item(key = "featured_carousel") {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = outerMargin),
                            horizontalArrangement = Arrangement.spacedBy(gutter)
                        ) {
                            items(featuredDeals, key = { "feat_${it.id}" }) { product ->
                                ProductCard(
                                    product = product,
                                    quantity = uiState.cartQuantities[product.id] ?: 0,
                                    isFavorite = uiState.favoriteIds.contains(product.id),
                                    onCardClick = { onProductClick(product.id) },
                                    onIncrement = { onIncrementCart(product.id) },
                                    onDecrement = { onDecrementCart(product.id) },
                                    onToggleFavorite = { onToggleFavorite(product.id) },
                                    modifier = Modifier.width(172.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }

                // Grid Section Header
                item(key = "grid_header") {
                    val sectionTitle = when {
                        uiState.showFavoritesOnly -> "Saved Favorites (${filteredProducts.size})"
                        uiState.searchQuery.isNotBlank() -> "Search Results (${filteredProducts.size})"
                        uiState.selectedHomeCategory != ProductCategory.ALL -> uiState.selectedHomeCategory.title
                        else -> "Everyday Local Essentials"
                    }
                    val sectionSub = when {
                        uiState.showFavoritesOnly -> "Your quick-reorder Assam pantry"
                        uiState.searchQuery.isNotBlank() -> "Matching \"${uiState.searchQuery.trim()}\""
                        uiState.selectedHomeCategory != ProductCategory.ALL -> uiState.selectedHomeCategory.tagline
                        else -> "Delivered fresh from ${uiState.selectedAddress.hubName}"
                    }
                    SectionHeaderRow(
                        title = sectionTitle,
                        subtitle = sectionSub,
                        modifier = Modifier.padding(horizontal = outerMargin)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                if (productRows.isEmpty()) {
                    item(key = "empty_results") {
                        EmptyCatalogState(
                            onReset = {
                                onSearchQueryChange("")
                                onSelectCategory(ProductCategory.ALL)
                                if (uiState.showFavoritesOnly) onToggleFavoritesOnly()
                            },
                            modifier = Modifier.padding(horizontal = outerMargin, vertical = 24.dp)
                        )
                    }
                } else {
                    items(productRows, key = { row -> row.joinToString("_") { it.id } }) { rowItems ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = outerMargin)
                                .padding(bottom = gutter),
                            horizontalArrangement = Arrangement.spacedBy(gutter)
                        ) {
                            for (i in 0 until columnsCount) {
                                if (i < rowItems.size) {
                                    val product = rowItems[i]
                                    ProductCard(
                                        product = product,
                                        quantity = uiState.cartQuantities[product.id] ?: 0,
                                        isFavorite = uiState.favoriteIds.contains(product.id),
                                        onCardClick = { onProductClick(product.id) },
                                        onIncrement = { onIncrementCart(product.id) },
                                        onDecrement = { onDecrementCart(product.id) },
                                        onToggleFavorite = { onToggleFavorite(product.id) },
                                        modifier = Modifier.weight(1f)
                                    )
                                } else {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AssamHeroBanner(
    hubName: String,
    onExploreClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF006B2C),
        modifier = modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF005320),
                            Color(0xFF006B2C),
                            Color(0xFF15803D)
                        )
                    )
                )
        ) {
            // Subtle tea-garden hillside contours
            Canvas(modifier = Modifier.matchParentSize()) {
                val w = size.width
                val h = size.height
                drawCircle(
                    color = Color(0x1A7FFC97),
                    radius = h * 0.68f,
                    center = Offset(w * 0.92f, h * 0.2f)
                )
                val hillPath = Path().apply {
                    moveTo(0f, h * 0.85f)
                    cubicTo(w * 0.3f, h * 0.62f, w * 0.65f, h * 0.95f, w, h * 0.68f)
                    lineTo(w, h)
                    lineTo(0f, h)
                    close()
                }
                drawPath(path = hillPath, color = Color(0x16FFFFFF))
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Surface(
                    color = Color.White.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(9999.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Storefront,
                            contentDescription = null,
                            tint = Color(0xFF92F5A4),
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "$hubName • Fresh Batch In",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = Color(0xFFF7FFF2)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Fresh from Upper Assam Gardens & Farms",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Save up to 22% on GI-tagged Joha rice, Kaji Nemu, and single-estate tea. Use code AXOM10.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFDCFCE7)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onExploreClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFF005320)
                    ),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                    modifier = Modifier.heightIn(min = 42.dp)
                ) {
                    Text(
                        text = "Browse All Categories",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeaderRow(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = AxomColors.TextPrimary
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = AxomColors.TextMuted
        )
    }
}

@Composable
private fun EmptyCatalogState(
    onReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AxomColors.CardWhite,
        border = BorderStroke(1.dp, AxomColors.BorderSubtle),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Rounded.Search,
                contentDescription = null,
                tint = AxomColors.EmeraldPrimary,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "No matching local items",
                style = MaterialTheme.typography.titleMedium,
                color = AxomColors.TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Try searching for tea, rice, milk, lemon, or reset your active filters.",
                style = MaterialTheme.typography.bodySmall,
                color = AxomColors.TextMuted
            )
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = onReset,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AxomColors.EmeraldPrimary,
                    contentColor = Color.White
                ),
                modifier = Modifier.height(48.dp)
            ) {
                Text("Reset Filters", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun HomeScreenPreview() {
    AxomMartTheme {
        HomeScreen(
            uiState = AxomUiState(),
            bottomContentPadding = 16.dp,
            onSearchQueryChange = {},
            onSelectCategory = {},
            onToggleFavoritesOnly = {},
            onProductClick = {},
            onIncrementCart = {},
            onDecrementCart = {},
            onToggleFavorite = {},
            onExploreDealsClick = {}
        )
    }
}
