package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddLocationAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.DeliveryAddress
import com.example.ui.theme.AxomColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationPickerBottomSheet(
    registeredAddress: DeliveryAddress,
    addresses: List<DeliveryAddress>,
    onSelectAddress: (String) -> Unit,
    onAddAddress: (label: String, fullAddress: String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showAddForm by remember { mutableStateOf(false) }
    var label by remember { mutableStateOf("Home") }
    var fullAddress by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        containerColor = AxomColors.CardWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
        ) {
            Text(
                text = if (showAddForm) "Add Delivery Address" else "Delivery Addresses",
                style = MaterialTheme.typography.headlineSmall,
                color = AxomColors.TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (showAddForm) {
                    "New street addresses are saved within your registered delivery area"
                } else {
                    "Choose or add a drop address in your registered area"
                },
                style = MaterialTheme.typography.bodySmall,
                color = AxomColors.TextMuted
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Permanent Registered Area Indicator
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = AxomColors.EmeraldSoftBg.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, AxomColors.EmeraldSoftBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = AxomColors.ForestSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Registered Area: ${registeredAddress.area}",
                            style = MaterialTheme.typography.labelLarge,
                            color = AxomColors.ForestSecondary
                        )
                        Text(
                            text = "${registeredAddress.hubName} • PIN ${registeredAddress.pinCode} • ${registeredAddress.etaMins} min delivery",
                            style = MaterialTheme.typography.bodySmall,
                            color = AxomColors.TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (!showAddForm) {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.heightIn(max = 300.dp)
                ) {
                    items(addresses, key = { it.docId.ifBlank { it.id.toString() } }) { address ->
                        AddressSelectionRow(
                            address = address,
                            onClick = {
                                onSelectAddress(address.docId)
                                onDismiss()
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = { showAddForm = true },
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, AxomColors.EmeraldPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_add_address_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AddLocationAlt,
                        contentDescription = null,
                        tint = AxomColors.EmeraldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Add Address in Registered Area",
                        style = MaterialTheme.typography.labelLarge,
                        color = AxomColors.EmeraldPrimary
                    )
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Home", "Office", "Other").forEach { preset ->
                        val selected = label == preset
                        Surface(
                            onClick = { label = preset },
                            shape = RoundedCornerShape(9999.dp),
                            color = if (selected) AxomColors.EmeraldPrimary else AxomColors.SurfaceTintGray,
                            modifier = Modifier.height(32.dp)
                        ) {
                            Box(
                                modifier = Modifier.padding(horizontal = 14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = preset,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) Color.White else AxomColors.TextPrimary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val cleanFull = fullAddress.trim()
                OutlinedTextField(
                    value = fullAddress,
                    onValueChange = { if (it.length <= 250) fullAddress = it },
                    label = { Text("House / Flat / Bylane / Landmark *") },
                    placeholder = { Text("e.g. House 14, Bylane 3, Near Mandir") },
                    supportingText = {
                        Text(
                            text = if (cleanFull.length < 5) "Minimum 5 characters" else "Locked to ${registeredAddress.area}",
                            color = AxomColors.TextMuted
                        )
                    },
                    singleLine = false,
                    minLines = 2,
                    maxLines = 3,
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AxomColors.EmeraldPrimary,
                        unfocusedBorderColor = AxomColors.BorderInput
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_street_address_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = { showAddForm = false },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, AxomColors.BorderInput),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("Back", color = AxomColors.TextPrimary)
                    }
                    Button(
                        onClick = {
                            onAddAddress(label, cleanFull)
                            onDismiss()
                        },
                        enabled = cleanFull.length >= 5,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AxomColors.EmeraldPrimary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("save_new_address_button")
                    ) {
                        Text("Save & Select")
                    }
                }
            }
        }
    }
}

@Composable
fun AddressSelectionRow(
    address: DeliveryAddress,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (address.isSelected) AxomColors.EmeraldSoftBg.copy(alpha = 0.55f) else AxomColors.CanvasSlate,
        border = BorderStroke(
            width = 1.dp,
            color = if (address.isSelected) AxomColors.EmeraldPrimary else AxomColors.BorderSubtle
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("address_row_${address.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        if (address.isSelected) AxomColors.EmeraldPrimary else AxomColors.SurfaceTintGray,
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.LocationOn,
                    contentDescription = null,
                    tint = if (address.isSelected) Color.White else AxomColors.TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = address.label,
                        style = MaterialTheme.typography.titleSmall,
                        color = AxomColors.TextPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = AxomColors.EmeraldSoftBg,
                        shape = RoundedCornerShape(9999.dp)
                    ) {
                        Text(
                            text = "${address.etaMins} mins",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                fontFeatureSettings = "tnum"
                            ),
                            color = AxomColors.ForestSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${address.fullAddress}, ${address.pinCode}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AxomColors.TextMuted
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = if (address.isSelected) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                contentDescription = if (address.isSelected) "Selected" else "Not selected",
                tint = if (address.isSelected) AxomColors.EmeraldPrimary else AxomColors.BorderInput
            )
        }
    }
}
