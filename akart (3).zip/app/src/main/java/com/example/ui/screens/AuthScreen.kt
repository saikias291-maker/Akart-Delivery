package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.CatalogData
import com.example.data.remote.AreaDoc
import com.example.data.remote.AxomDataRepository
import com.example.ui.auth.CustomerSession
import com.example.ui.theme.AxomColors
import com.example.ui.theme.AxomMartTheme
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

private enum class AuthCardMode {
    REGISTER,
    RETRIEVE
}

@Composable
fun AuthScreen(
    repository: AxomDataRepository?,
    onSessionEstablished: (CustomerSession) -> Unit,
    modifier: Modifier = Modifier
) {
    var areas by remember { mutableStateOf<List<AreaDoc>>(emptyList()) }
    var isLoadingAreas by remember { mutableStateOf(repository != null) }

    LaunchedEffect(repository) {
        if (repository == null) {
            areas = CatalogData.defaultServiceAreas
            isLoadingAreas = false
            return@LaunchedEffect
        }
        isLoadingAreas = true
        repository.observeServiceAreas()
            .catch {
                areas = CatalogData.defaultServiceAreas
                isLoadingAreas = false
            }
            .collect { loaded ->
                areas = loaded
                isLoadingAreas = false
            }
    }

    AuthScreenContent(
        areas = areas,
        isLoadingAreas = isLoadingAreas,
        onRegister = { fullName, mobile, area, address ->
            val repo = repository ?: return@AuthScreenContent Result.failure(
                IllegalStateException("Repository unavailable")
            )
            repo.registerCustomer(
                fullName = fullName,
                mobileNumber = mobile,
                area = area,
                fullAddress = address
            )
        },
        onRetrieveByMobile = { mobile ->
            val repo = repository ?: return@AuthScreenContent Result.failure(
                IllegalStateException("Repository unavailable")
            )
            repo.retrieveCustomerByMobile(mobile)
        },
        onSessionEstablished = onSessionEstablished,
        modifier = modifier
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreenContent(
    areas: List<AreaDoc>,
    isLoadingAreas: Boolean,
    onRegister: suspend (fullName: String, mobile: String, area: AreaDoc, fullAddress: String) -> Result<CustomerSession>,
    onRetrieveByMobile: suspend (mobile: String) -> Result<CustomerSession>,
    onSessionEstablished: (CustomerSession) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(AuthCardMode.REGISTER) }

    // Registration fields
    var fullName by remember { mutableStateOf("") }
    var mobileNumber by remember { mutableStateOf("") }
    var selectedArea by remember { mutableStateOf<AreaDoc?>(null) }
    var areaDropdownExpanded by remember { mutableStateOf(false) }
    var fullAddress by remember { mutableStateOf("") }

    // Retrieve profile field
    var lookupMobile by remember { mutableStateOf("") }

    var isSubmitting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(areas) {
        if (selectedArea != null && areas.none { it.areaId == selectedArea?.areaId }) {
            selectedArea = null
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AxomColors.CanvasSlate)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 480.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Hero Brand Header Card (Preserved AKART logo, green-and-white theme, Assamese tagline)
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = AxomColors.ForestSecondary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF005320),
                                    Color(0xFF006B2C),
                                    Color(0xFF16A34A)
                                )
                            )
                        )
                ) {
                    Canvas(modifier = Modifier.matchParentSize()) {
                        val w = size.width
                        val h = size.height
                        drawCircle(
                            color = Color(0x1E7FFC97),
                            radius = h * 0.52f,
                            center = Offset(w * 0.9f, h * 0.16f)
                        )
                        val wave = Path().apply {
                            moveTo(0f, h * 0.8f)
                            cubicTo(w * 0.35f, h * 0.58f, w * 0.7f, h * 0.94f, w, h * 0.72f)
                            lineTo(w, h)
                            lineTo(0f, h)
                            close()
                        }
                        drawPath(path = wave, color = Color(0x14FFFFFF))
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.akart_launcher_art),
                            contentDescription = "AKART logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(68.dp)
                                .clip(RoundedCornerShape(16.dp))
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "AKART",
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Assam's 12-Min Hyperlocal Basket",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFFDCFCE7),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AuthFeatureChip(icon = Icons.Rounded.Bolt, text = "12m Express")
                            AuthFeatureChip(icon = Icons.Rounded.Verified, text = "GI Assam")
                            AuthFeatureChip(icon = Icons.Rounded.Eco, text = "Farm Fresh")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Mode Switcher Card (Register vs Retrieve Existing Profile)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = AxomColors.CardWhite,
                border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Segmented Switcher
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AxomColors.SurfaceTintGray,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ModeSegmentTab(
                                label = "New Customer",
                                selected = mode == AuthCardMode.REGISTER,
                                onClick = {
                                    mode = AuthCardMode.REGISTER
                                    errorMessage = null
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("mode_register_tab")
                            )
                            ModeSegmentTab(
                                label = "Retrieve Profile",
                                selected = mode == AuthCardMode.RETRIEVE,
                                onClick = {
                                    mode = AuthCardMode.RETRIEVE
                                    errorMessage = null
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("mode_retrieve_tab")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (mode == AuthCardMode.REGISTER) {
                        Text(
                            text = "Register Your Delivery Profile",
                            style = MaterialTheme.typography.headlineSmall,
                            color = AxomColors.TextPrimary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Your selected delivery area is permanently linked to your customer profile for local hub stock and pricing.",
                            style = MaterialTheme.typography.bodySmall,
                            color = AxomColors.TextMuted,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // 1. Customer Full Name
                        OutlinedTextField(
                            value = fullName,
                            onValueChange = {
                                if (it.length <= 80) fullName = it
                                errorMessage = null
                            },
                            label = { Text("Customer Full Name *") },
                            placeholder = { Text("e.g. Bhaskar Jyoti Das") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Person,
                                    contentDescription = null,
                                    tint = AxomColors.EmeraldPrimary
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Words
                            ),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AxomColors.EmeraldPrimary,
                                unfocusedBorderColor = AxomColors.BorderInput
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("reg_name_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // 2. Mobile Number (exactly 10 digits)
                        OutlinedTextField(
                            value = mobileNumber,
                            onValueChange = { raw ->
                                val digits = raw.filter { it.isDigit() }.take(10)
                                mobileNumber = digits
                                errorMessage = null
                            },
                            label = { Text("Mobile Number (10 digits) *") },
                            placeholder = { Text("10-digit mobile number") },
                            prefix = { Text("+91 ") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Phone,
                                    contentDescription = null,
                                    tint = AxomColors.EmeraldPrimary
                                )
                            },
                            supportingText = {
                                Text(
                                    text = "${mobileNumber.length}/10 digits",
                                    color = if (mobileNumber.length == 10) AxomColors.ForestSecondary else AxomColors.TextMuted
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AxomColors.EmeraldPrimary,
                                unfocusedBorderColor = AxomColors.BorderInput
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("reg_mobile_input")
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // 3. Select Delivery Area (populated from Firestore areas collection)
                        ExposedDropdownMenuBox(
                            expanded = areaDropdownExpanded,
                            onExpandedChange = {
                                if (!isLoadingAreas && areas.isNotEmpty()) {
                                    areaDropdownExpanded = !areaDropdownExpanded
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = when {
                                    isLoadingAreas -> "Loading delivery areas…"
                                    selectedArea != null -> "${selectedArea!!.name} (${selectedArea!!.defaultEtaMins} min)"
                                    else -> ""
                                },
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Select Delivery Area *") },
                                placeholder = { Text("Choose your Assam neighbourhood") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.LocationOn,
                                        contentDescription = null,
                                        tint = AxomColors.EmeraldPrimary
                                    )
                                },
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = areaDropdownExpanded)
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AxomColors.EmeraldPrimary,
                                    unfocusedBorderColor = AxomColors.BorderInput
                                ),
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth()
                                    .testTag("reg_area_dropdown")
                            )

                            ExposedDropdownMenu(
                                expanded = areaDropdownExpanded,
                                onDismissRequest = { areaDropdownExpanded = false }
                            ) {
                                areas.forEach { area ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(
                                                    text = area.name,
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                                    color = AxomColors.TextPrimary
                                                )
                                                Text(
                                                    text = "${area.hubName} • ${area.defaultEtaMins} min delivery",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = AxomColors.TextMuted
                                                )
                                            }
                                        },
                                        onClick = {
                                            selectedArea = area
                                            areaDropdownExpanded = false
                                            errorMessage = null
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 4. Full Delivery Address
                        OutlinedTextField(
                            value = fullAddress,
                            onValueChange = {
                                if (it.length <= 250) fullAddress = it
                                errorMessage = null
                            },
                            label = { Text("Full Delivery Address *") },
                            placeholder = { Text("House / Flat No., Bylane, Landmark") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Home,
                                    contentDescription = null,
                                    tint = AxomColors.EmeraldPrimary
                                )
                            },
                            minLines = 2,
                            maxLines = 3,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Sentences
                            ),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AxomColors.EmeraldPrimary,
                                unfocusedBorderColor = AxomColors.BorderInput
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("reg_address_input")
                        )

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            ErrorBannerBox(message = errorMessage!!)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val cleanName = fullName.trim()
                                val cleanMobile = mobileNumber.trim()
                                val chosenArea = selectedArea
                                val cleanAddress = fullAddress.trim()

                                val validationError = when {
                                    cleanName.length < 2 -> "Please enter your full name (at least 2 characters)."
                                    cleanMobile.length != 10 || !cleanMobile.all { it.isDigit() } ->
                                        "Mobile number must be exactly 10 digits."
                                    chosenArea == null -> "Please select your delivery area from the dropdown."
                                    cleanAddress.length < 5 ->
                                        "Please enter your complete delivery address (at least 5 characters)."
                                    else -> null
                                }
                                if (validationError != null) {
                                    errorMessage = validationError
                                    return@Button
                                }

                                errorMessage = null
                                isSubmitting = true
                                scope.launch {
                                    val result = onRegister(cleanName, cleanMobile, chosenArea!!, cleanAddress)
                                    isSubmitting = false
                                    result.onSuccess { session ->
                                        onSessionEstablished(session)
                                    }.onFailure { err ->
                                        errorMessage = err.localizedMessage ?: "Registration failed. Please try again."
                                    }
                                }
                            },
                            enabled = !isSubmitting && !isLoadingAreas,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AxomColors.EmeraldPrimary,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("register_button")
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Registering…", style = MaterialTheme.typography.labelLarge)
                            } else {
                                Text(
                                    text = "REGISTER",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    } else {
                        // Retrieve Existing Profile Mode
                        Text(
                            text = "Retrieve Existing Profile",
                            style = MaterialTheme.typography.headlineSmall,
                            color = AxomColors.TextPrimary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Enter the 10-digit mobile number you used when registering on AKART to restore your saved profile and order history.",
                            style = MaterialTheme.typography.bodySmall,
                            color = AxomColors.TextMuted,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AxomColors.AmberSoftBg,
                            border = BorderStroke(1.dp, AxomColors.AmberRating.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Info,
                                    contentDescription = null,
                                    tint = AxomColors.AmberRating,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Profile lookup uses your mobile number directly without OTP identity verification.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AxomColors.TextPrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = lookupMobile,
                            onValueChange = { raw ->
                                lookupMobile = raw.filter { it.isDigit() }.take(10)
                                errorMessage = null
                            },
                            label = { Text("Registered Mobile Number (10 digits) *") },
                            placeholder = { Text("10-digit mobile number") },
                            prefix = { Text("+91 ") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Phone,
                                    contentDescription = null,
                                    tint = AxomColors.EmeraldPrimary
                                )
                            },
                            supportingText = {
                                Text(
                                    text = "${lookupMobile.length}/10 digits",
                                    color = if (lookupMobile.length == 10) AxomColors.ForestSecondary else AxomColors.TextMuted
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AxomColors.EmeraldPrimary,
                                unfocusedBorderColor = AxomColors.BorderInput
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("retrieve_mobile_input")
                        )

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            ErrorBannerBox(message = errorMessage!!)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val cleanMobile = lookupMobile.trim()
                                if (cleanMobile.length != 10 || !cleanMobile.all { it.isDigit() }) {
                                    errorMessage = "Please enter an exact 10-digit mobile number."
                                    return@Button
                                }
                                errorMessage = null
                                isSubmitting = true
                                scope.launch {
                                    val result = onRetrieveByMobile(cleanMobile)
                                    isSubmitting = false
                                    result.onSuccess { session ->
                                        onSessionEstablished(session)
                                    }.onFailure { err ->
                                        errorMessage = err.localizedMessage ?: "No saved profile found for this number."
                                    }
                                }
                            },
                            enabled = !isSubmitting,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AxomColors.EmeraldPrimary,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("retrieve_profile_button")
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Looking up profile…", style = MaterialTheme.typography.labelLarge)
                            } else {
                                Text(
                                    text = "RETRIEVE PROFILE",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeSegmentTab(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (selected) AxomColors.EmeraldPrimary else Color.Transparent,
        modifier = modifier.height(40.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                ),
                color = if (selected) Color.White else AxomColors.TextPrimary
            )
        }
    }
}

@Composable
private fun ErrorBannerBox(message: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = AxomColors.RedSoftBg,
        border = BorderStroke(1.dp, AxomColors.RedDiscount.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = AxomColors.RedDiscount,
            modifier = Modifier.padding(12.dp)
        )
    }
}

@Composable
private fun AuthFeatureChip(
    icon: ImageVector,
    text: String
) {
    Surface(
        color = Color.White.copy(alpha = 0.15f),
        shape = RoundedCornerShape(9999.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF92F5A4),
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                color = Color.White
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun AuthScreenPreview() {
    AxomMartTheme {
        AuthScreenContent(
            areas = CatalogData.defaultServiceAreas,
            isLoadingAreas = false,
            onRegister = { _, _, _, _ -> Result.failure(IllegalStateException("Preview")) },
            onRetrieveByMobile = { Result.failure(IllegalStateException("Preview")) },
            onSessionEstablished = {}
        )
    }
}
