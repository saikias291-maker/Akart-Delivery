package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand & Semantic Tokens from Assam Hyperlocal Commerce Design System
val SurfacePrimary = Color(0xFFF7F9FB)
val SurfaceBright = Color(0xFFF7F9FB)
val SurfaceDim = Color(0xFFD8DADC)
val SurfaceContainerLowest = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFF2F4F6)
val SurfaceContainer = Color(0xFFECEEF0)
val SurfaceContainerHigh = Color(0xFFE6E8EA)
val SurfaceContainerHighest = Color(0xFFE0E3E5)

val OnSurfacePrimary = Color(0xFF191C1E)
val OnSurfaceVariant = Color(0xFF3E4A3D)
val InverseSurface = Color(0xFF2D3133)
val InverseOnSurface = Color(0xFFEFF1F3)

val OutlinePrimary = Color(0xFF6E7B6C)
val OutlineVariant = Color(0xFFBDCABA)

val PrimaryGreen = Color(0xFF006B2C)
val OnPrimaryWhite = Color(0xFFFFFFFF)
val PrimaryContainerGreen = Color(0xFF00873A)
val OnPrimaryContainerMint = Color(0xFFF7FFF2)
val InversePrimaryMint = Color(0xFF62DF7D)

val SecondaryGreen = Color(0xFF006D30)
val OnSecondaryWhite = Color(0xFFFFFFFF)
val SecondaryContainerMint = Color(0xFF92F5A4)
val OnSecondaryContainerGreen = Color(0xFF007233)

val TertiaryBerry = Color(0xFFA72D51)
val OnTertiaryWhite = Color(0xFFFFFFFF)
val TertiaryContainerBerry = Color(0xFFC74668)
val OnTertiaryContainerWhite = Color(0xFFFFFBFF)

val ErrorRed = Color(0xFFBA1A1A)
val OnErrorWhite = Color(0xFFFFFFFF)
val ErrorContainerRed = Color(0xFFFFDAD6)
val OnErrorContainerRed = Color(0xFF93000A)

val PrimaryFixed = Color(0xFF7FFC97)
val PrimaryFixedDim = Color(0xFF62DF7D)
val OnPrimaryFixed = Color(0xFF002109)

// High-clarity Component Palette Tokens
object AxomColors {
    val EmeraldPrimary = Color(0xFF16A34A)
    val ForestSecondary = Color(0xFF15803D)
    val DeepForest = Color(0xFF005320)
    val CanvasSlate = Color(0xFFF8FAFC)
    val SurfaceTintGray = Color(0xFFF1F5F9)
    val CardWhite = Color(0xFFFFFFFF)
    val BorderSubtle = Color(0xFFE2E8F0)
    val BorderInput = Color(0xFFCBD5E1)
    val TextPrimary = Color(0xFF0F172A)
    val TextMuted = Color(0xFF475569)
    val TextInactiveNav = Color(0xFF64748B)
    val AmberRating = Color(0xFFD97706)
    val AmberSoftBg = Color(0xFFFEF3C7)
    val RedDiscount = Color(0xFFDC2626)
    val RedSoftBg = Color(0xFFFEE2E2)
    val EmeraldSoftBg = Color(0xFFDCFCE7)
    val EmeraldSoftBorder = Color(0xFFBBF7D0)
}
