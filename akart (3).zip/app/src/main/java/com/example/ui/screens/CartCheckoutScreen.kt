package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LocalOffer
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.CatalogData
import com.example.model.CartLineItem
import com.example.model.DeliverySlot
import com.example.model.PaymentMethod
import com.example.ui.AxomUiState
import com.example.ui.components.AddToCartStepper
import com.example.ui.components.ProductImageBox
import com.example.ui.theme.AxomColors

@Composable
fun CartCheckoutScreen(
    uiState: AxomUiState,
    onBack: () -> Unit,
    onOpenLocationPicker: () -> Unit,
    onIncrementCart: (String) -> Unit,
    onDecrementCart: (String) -> Unit,
    onSelectDeliverySlot: (DeliverySlot) -> Unit,
    onSelectPaymentMethod: (PaymentMethod) -> Unit,
    onApplyPromo: (String) -> Unit,
    onClearPromo: () -> Unit,
    onPlaceOrder: () -> Unit,
    onBrowseProducts: () -> Unit,
    modifier: Modifier = Modifier
) {
    var promoInput by remember(uiState.appliedPromoCode) {
        mutableStateOf(uiState.appliedPromoCode ?: "")
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxomColors.CanvasSlate)
    ) {
        // Top App Bar
        Surface(
            color = AxomColors.CardWhite,
            border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.size(48.dp).testTag("cart_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        tint = AxomColors.TextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "Your Basket",
                        style = MaterialTheme.typography.titleLarge,
                        color = AxomColors.TextPrimary
                    )
                    if (uiState.totalCartCount > 0) {
                        Text(
                            text = "${uiState.totalCartCount} items • ${uiState.selectedAddress.hubName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = AxomColors.TextMuted
                        )
                    }
                }
            }
        }

        if (uiState.cartItems.isEmpty()) {
            // Empty Basket State
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = AxomColors.CardWhite,
                    border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(68.dp)
                                .background(AxomColors.EmeraldSoftBg, RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ShoppingBag,
                                contentDescription = null,
                                tint = AxomColors.EmeraldPrimary,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Your basket is empty",
                            style = MaterialTheme.typography.headlineSmall,
                            color = AxomColors.TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Add Upper Assam teas, Kaji Nemu, Joha rice, or dairy essentials for 12-min doorstep delivery.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AxomColors.TextMuted
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onBrowseProducts,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AxomColors.EmeraldPrimary,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("empty_cart_browse_button")
                        ) {
                            Text("Browse Local Products", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Free delivery progress banner
                item {
                    val unlocked = uiState.freeDeliveryThresholdRemaining == 0
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (unlocked) AxomColors.EmeraldSoftBg else AxomColors.CardWhite,
                        border = BorderStroke(
                            1.dp,
                            if (unlocked) AxomColors.EmeraldSoftBorder else AxomColors.BorderSubtle
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = if (unlocked) AxomColors.ForestSecondary else AxomColors.AmberRating,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (unlocked) {
                                        "You unlocked FREE local delivery!"
                                    } else {
                                        "Add ₹${uiState.freeDeliveryThresholdRemaining} more for FREE delivery (saves ₹25)"
                                    },
                                    style = MaterialTheme.typography.labelLarge.copy(fontFeatureSettings = "tnum"),
                                    color = if (unlocked) AxomColors.ForestSecondary else AxomColors.TextPrimary
                                )
                            }
                            if (!unlocked) {
                                Spacer(modifier = Modifier.height(8.dp))
                                val progress = (uiState.cartSubtotalRupees / 199f).coerceIn(0f, 1f)
                                LinearProgressIndicator(
                                    progress = { progress },
                                    color = AxomColors.EmeraldPrimary,
                                    trackColor = AxomColors.SurfaceTintGray,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(9999.dp))
                                )
                            }
                        }
                    }
                }

                // Delivery Address Card
                item {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AxomColors.CardWhite,
                        border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.LocationOn,
                                contentDescription = null,
                                tint = AxomColors.EmeraldPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Delivering to ${uiState.selectedAddress.label}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = AxomColors.TextPrimary
                                )
                                Text(
                                    text = "${uiState.selectedAddress.fullAddress}, ${uiState.selectedAddress.pinCode}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AxomColors.TextMuted,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            TextButton(
                                onClick = onOpenLocationPicker,
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text(
                                    text = "Change",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = AxomColors.EmeraldPrimary
                                )
                            }
                        }
                    }
                }

                // Delivery Slot Selector
                item {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AxomColors.CardWhite,
                        border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Delivery Slot",
                                style = MaterialTheme.typography.titleSmall,
                                color = AxomColors.TextPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(DeliverySlot.entries, key = { it.id }) { slot ->
                                    val selected = uiState.selectedSlot == slot
                                    Surface(
                                        onClick = { onSelectDeliverySlot(slot) },
                                        shape = RoundedCornerShape(9999.dp),
                                        color = if (selected) AxomColors.EmeraldPrimary else AxomColors.SurfaceTintGray,
                                        modifier = Modifier.heightIn(min = 36.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = slot.label,
                                                style = MaterialTheme.typography.labelMedium,
                                                color = if (selected) Color.White else AxomColors.TextPrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Cart Line Items
                item {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AxomColors.CardWhite,
                        border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            uiState.cartItems.forEachIndexed { index, lineItem ->
                                CartItemRow(
                                    item = lineItem,
                                    onIncrement = { onIncrementCart(lineItem.product.id) },
                                    onDecrement = { onDecrementCart(lineItem.product.id) }
                                )
                                if (index < uiState.cartItems.lastIndex) {
                                    HorizontalDivider(color = AxomColors.SurfaceTintGray)
                                }
                            }
                        }
                    }
                }

                // Promo Code Card
                item {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AxomColors.CardWhite,
                        border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.LocalOffer,
                                    contentDescription = null,
                                    tint = AxomColors.EmeraldPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Apply Promo Code",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = AxomColors.TextPrimary
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = promoInput,
                                    onValueChange = { promoInput = it.uppercase() },
                                    placeholder = { Text("Enter AXOM10 or BIHU50") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = AxomColors.EmeraldPrimary,
                                        unfocusedBorderColor = AxomColors.BorderInput
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                if (uiState.appliedPromoCode != null) {
                                    OutlinedButton(
                                        onClick = {
                                            promoInput = ""
                                            onClearPromo()
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, AxomColors.RedDiscount),
                                        modifier = Modifier.height(52.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Remove promo",
                                            tint = AxomColors.RedDiscount,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                } else {
                                    Button(
                                        onClick = { onApplyPromo(promoInput) },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = AxomColors.EmeraldPrimary,
                                            contentColor = Color.White
                                        ),
                                        modifier = Modifier.height(52.dp)
                                    ) {
                                        Text("Apply", style = MaterialTheme.typography.labelLarge)
                                    }
                                }
                            }

                            uiState.promoMessage?.let { msg ->
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = msg,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (uiState.promoDiscountRupees > 0) AxomColors.ForestSecondary else AxomColors.AmberRating
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(CatalogData.promoOffers, key = { it.code }) { offer ->
                                    val isApplied = uiState.appliedPromoCode.equals(offer.code, ignoreCase = true)
                                    Surface(
                                        onClick = {
                                            promoInput = offer.code
                                            onApplyPromo(offer.code)
                                        },
                                        shape = RoundedCornerShape(9999.dp),
                                        color = if (isApplied) AxomColors.EmeraldSoftBg else AxomColors.SurfaceTintGray,
                                        border = BorderStroke(
                                            1.dp,
                                            if (isApplied) AxomColors.EmeraldPrimary else AxomColors.BorderSubtle
                                        ),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier.padding(horizontal = 12.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "${offer.code} • ${offer.title}",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                                color = if (isApplied) AxomColors.ForestSecondary else AxomColors.TextPrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Payment Method Card
                item {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AxomColors.CardWhite,
                        border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Payment Method",
                                style = MaterialTheme.typography.titleSmall,
                                color = AxomColors.TextPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            PaymentMethod.entries.forEachIndexed { idx, method ->
                                val selected = uiState.selectedPayment == method
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 56.dp)
                                        .clickable { onSelectPaymentMethod(method) }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (selected) Icons.Rounded.RadioButtonChecked else Icons.Rounded.RadioButtonUnchecked,
                                        contentDescription = null,
                                        tint = if (selected) AxomColors.EmeraldPrimary else AxomColors.BorderInput
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = method.title,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                            color = AxomColors.TextPrimary
                                        )
                                        Text(
                                            text = method.subtitle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = AxomColors.TextMuted
                                        )
                                    }
                                }
                                if (idx < PaymentMethod.entries.lastIndex) {
                                    HorizontalDivider(color = AxomColors.SurfaceTintGray)
                                }
                            }
                        }
                    }
                }

                // Bill Summary Card
                item {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AxomColors.CardWhite,
                        border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Bill Summary",
                                style = MaterialTheme.typography.titleSmall,
                                color = AxomColors.TextPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            BillRow(label = "Item Total", value = "₹${uiState.cartSubtotalRupees}")
                            if (uiState.itemSavingsRupees > 0) {
                                BillRow(
                                    label = "MRP Savings",
                                    value = "-₹${uiState.itemSavingsRupees}",
                                    valueColor = AxomColors.ForestSecondary
                                )
                            }
                            BillRow(
                                label = "Delivery Fee",
                                value = if (uiState.deliveryFeeRupees == 0) "FREE" else "₹${uiState.deliveryFeeRupees}",
                                valueColor = if (uiState.deliveryFeeRupees == 0) AxomColors.ForestSecondary else AxomColors.TextPrimary
                            )
                            if (uiState.promoDiscountRupees > 0) {
                                BillRow(
                                    label = "Promo (${uiState.appliedPromoCode})",
                                    value = "-₹${uiState.promoDiscountRupees}",
                                    valueColor = AxomColors.ForestSecondary
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = AxomColors.BorderSubtle)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "To Pay",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = AxomColors.TextPrimary
                                )
                                Text(
                                    text = "₹${uiState.grandTotalRupees}",
                                    style = MaterialTheme.typography.headlineSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontFeatureSettings = "tnum"
                                    ),
                                    color = AxomColors.TextPrimary
                                )
                            }
                        }
                    }
                }
            }

            // Sticky Place Order Footer
            Surface(
                color = AxomColors.CardWhite,
                border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 6.dp,
                        ambientColor = Color(0x140F172A),
                        spotColor = Color(0x140F172A)
                    )
            ) {
                Box(
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Button(
                        onClick = onPlaceOrder,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AxomColors.EmeraldPrimary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("place_order_button")
                    ) {
                        Text(
                            text = "Place Order  •  ₹${uiState.grandTotalRupees}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFeatureSettings = "tnum"
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CartItemRow(
    item: CartLineItem,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 72.dp)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ProductImageBox(
            product = item.product,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.product.name,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = AxomColors.TextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${item.product.unit} • ₹${item.product.priceRupees}/unit",
                style = MaterialTheme.typography.bodySmall.copy(fontFeatureSettings = "tnum"),
                color = AxomColors.TextMuted
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            AddToCartStepper(
                productId = "cart_${item.product.id}",
                quantity = item.quantity,
                onIncrement = onIncrement,
                onDecrement = onDecrement,
                compact = true,
                modifier = Modifier.width(104.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "₹${item.lineTotalRupees}",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontFeatureSettings = "tnum"
                ),
                color = AxomColors.TextPrimary
            )
        }
    }
}

@Composable
private fun BillRow(
    label: String,
    value: String,
    valueColor: Color = AxomColors.TextPrimary
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = AxomColors.TextMuted
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                fontFeatureSettings = "tnum"
            ),
            color = valueColor
        )
    }
}
