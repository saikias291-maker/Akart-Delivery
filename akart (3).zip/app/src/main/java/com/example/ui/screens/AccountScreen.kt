package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.AddLocationAlt
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LocalShipping
import androidx.compose.material.icons.rounded.Recycling
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.AxomUiState
import com.example.ui.components.AddressSelectionRow
import com.example.ui.theme.AxomColors

@Composable
fun AccountScreen(
    uiState: AxomUiState,
    bottomContentPadding: Dp,
    onSelectAddress: (String) -> Unit,
    onOpenAddAddressSheet: () -> Unit,
    onUpdateProfile: (name: String, phone: String) -> Unit,
    onSetLeaveAtDoor: (Boolean) -> Unit,
    onSetEcoClothBag: (Boolean) -> Unit,
    onOpenFavoritesOnHome: () -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showEditProfileDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxomColors.CanvasSlate)
    ) {
        Surface(
            color = AxomColors.CardWhite,
            border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Text(
                    text = "Account",
                    style = MaterialTheme.typography.headlineMedium,
                    color = AxomColors.TextPrimary
                )
                Text(
                    text = "Manage Assam delivery addresses & preferences",
                    style = MaterialTheme.typography.bodySmall,
                    color = AxomColors.TextMuted
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 14.dp,
                bottom = bottomContentPadding + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Shopper Profile Card
            item {
                val initials = uiState.userPreferences.shopperName
                    .split(" ")
                    .filter { it.isNotBlank() }
                    .take(2)
                    .joinToString("") { it.first().uppercaseChar().toString() }
                    .ifEmpty { "AS" }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AxomColors.CardWhite,
                    border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .background(AxomColors.EmeraldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = initials,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = uiState.userPreferences.shopperName.ifBlank { "AKART Customer" },
                                style = MaterialTheme.typography.titleMedium,
                                color = AxomColors.TextPrimary
                            )
                            val phoneDigits = uiState.userPreferences.shopperPhone.filter { it.isDigit() }.takeLast(10)
                            Text(
                                text = if (phoneDigits.length == 10) "+91 $phoneDigits" else uiState.userPreferences.shopperPhone,
                                style = MaterialTheme.typography.bodySmall.copy(fontFeatureSettings = "tnum"),
                                color = AxomColors.TextMuted
                            )
                            Text(
                                text = "Area (Permanent): ${uiState.selectedAddress.area} • ${uiState.selectedAddress.pinCode}",
                                style = MaterialTheme.typography.labelSmall,
                                color = AxomColors.ForestSecondary
                            )
                            if (uiState.customerId.isNotBlank()) {
                                Text(
                                    text = "ID: ${uiState.customerId}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AxomColors.TextMuted
                                )
                            }
                        }
                        IconButton(
                            onClick = { showEditProfileDialog = true },
                            modifier = Modifier.size(48.dp).testTag("edit_profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Edit,
                                contentDescription = "Edit profile",
                                tint = AxomColors.EmeraldPrimary
                            )
                        }
                    }
                }
            }

            // Saved Favorites Quick Card
            item {
                Surface(
                    onClick = onOpenFavoritesOnHome,
                    shape = RoundedCornerShape(8.dp),
                    color = AxomColors.CardWhite,
                    border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 56.dp)
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(AxomColors.RedSoftBg, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Favorite,
                                    contentDescription = null,
                                    tint = AxomColors.RedDiscount,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Saved Favorites",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = AxomColors.TextPrimary
                                )
                                Text(
                                    text = "${uiState.favoriteIds.size} bookmarked Assam items",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AxomColors.TextMuted
                                )
                            }
                        }
                        Text(
                            text = "View →",
                            style = MaterialTheme.typography.labelLarge,
                            color = AxomColors.EmeraldPrimary
                        )
                    }
                }
            }

            // Saved Addresses Section
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AxomColors.CardWhite,
                    border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Saved Delivery Addresses",
                                style = MaterialTheme.typography.titleSmall,
                                color = AxomColors.TextPrimary
                            )
                            TextButton(
                                onClick = onOpenAddAddressSheet,
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.AddLocationAlt,
                                    contentDescription = null,
                                    tint = AxomColors.EmeraldPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Manage",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = AxomColors.EmeraldPrimary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            uiState.addresses.forEach { address ->
                                AddressSelectionRow(
                                    address = address,
                                    onClick = { onSelectAddress(address.docId) }
                                )
                            }
                        }
                    }
                }
            }

            // Delivery Preferences Section
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AxomColors.CardWhite,
                    border = BorderStroke(1.dp, AxomColors.BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text(
                            text = "Delivery Preferences",
                            style = MaterialTheme.typography.titleSmall,
                            color = AxomColors.TextPrimary,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                        PreferenceSwitchRow(
                            icon = Icons.Rounded.LocalShipping,
                            title = "Contactless drop at gate/door",
                            subtitle = "Rider leaves parcel safely and rings bell",
                            checked = uiState.userPreferences.leaveAtDoor,
                            onCheckedChange = onSetLeaveAtDoor
                        )
                        HorizontalDivider(color = AxomColors.SurfaceTintGray)
                        PreferenceSwitchRow(
                            icon = Icons.Rounded.Recycling,
                            title = "Eco cloth & paper packaging",
                            subtitle = "Avoid single-use plastic bags on fresh produce",
                            checked = uiState.userPreferences.ecoClothBag,
                            onCheckedChange = onSetEcoClothBag
                        )
                    }
                }
            }

            // Hyperlocal Hub Info
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AxomColors.EmeraldSoftBg.copy(alpha = 0.55f),
                    border = BorderStroke(1.dp, AxomColors.EmeraldSoftBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Storefront,
                            contentDescription = null,
                            tint = AxomColors.ForestSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Active Hub: ${uiState.selectedAddress.hubName}",
                                style = MaterialTheme.typography.titleSmall,
                                color = AxomColors.ForestSecondary
                            )
                            Text(
                                text = "Serving Guwahati, Jorhat, Dibrugarh & Tezpur • 6 AM – 11 PM daily",
                                style = MaterialTheme.typography.bodySmall,
                                color = AxomColors.TextMuted
                            )
                        }
                    }
                }
            }

            // Sign Out Button
            item {
                OutlinedButton(
                    onClick = onSignOut,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, AxomColors.RedDiscount.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("sign_out_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Logout,
                        contentDescription = null,
                        tint = AxomColors.RedDiscount,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Logout",
                        style = MaterialTheme.typography.labelLarge,
                        color = AxomColors.RedDiscount
                    )
                }
            }
        }
    }

    if (showEditProfileDialog) {
        EditProfileDialog(
            initialName = uiState.userPreferences.shopperName,
            initialPhone = uiState.userPreferences.shopperPhone,
            onSave = { name, phone ->
                onUpdateProfile(name, phone)
                showEditProfileDialog = false
            },
            onDismiss = { showEditProfileDialog = false }
        )
    }
}

@Composable
private fun PreferenceSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AxomColors.ForestSecondary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = AxomColors.TextPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = AxomColors.TextMuted
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = AxomColors.EmeraldPrimary,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = AxomColors.BorderInput
            )
        )
    }
}

@Composable
private fun EditProfileDialog(
    initialName: String,
    initialPhone: String,
    onSave: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var phone by remember {
        mutableStateOf(initialPhone.filter { it.isDigit() }.takeLast(10))
    }

    val cleanName = name.trim()
    val isNameValid = cleanName.length >= 2
    val isPhoneValid = phone.length == 10 && phone.all { it.isDigit() }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AxomColors.CardWhite,
        title = {
            Text(
                text = "Edit Customer Profile",
                style = MaterialTheme.typography.headlineSmall,
                color = AxomColors.TextPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= 80) name = it },
                    label = { Text("Customer Full Name *") },
                    supportingText = if (!isNameValid && name.isNotEmpty()) {
                        { Text("Minimum 2 characters", color = AxomColors.RedDiscount) }
                    } else null,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AxomColors.EmeraldPrimary,
                        unfocusedBorderColor = AxomColors.BorderInput
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { raw -> phone = raw.filter { it.isDigit() }.take(10) },
                    label = { Text("Mobile Number (10 digits) *") },
                    prefix = { Text("+91 ") },
                    supportingText = {
                        Text(
                            text = "${phone.length}/10 digits",
                            color = if (isPhoneValid) AxomColors.ForestSecondary else AxomColors.TextMuted
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AxomColors.EmeraldPrimary,
                        unfocusedBorderColor = AxomColors.BorderInput
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(cleanName, phone) },
                enabled = isNameValid && isPhoneValid,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AxomColors.EmeraldPrimary,
                    contentColor = Color.White
                )
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Cancel", color = AxomColors.TextPrimary)
            }
        }
    )
}
