package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.CatalogData
import com.example.data.remote.FirestoreRepository
import com.example.ui.AxomViewModel
import com.example.ui.auth.CustomerSessionManager
import com.example.ui.components.LocationPickerBottomSheet
import com.example.ui.components.StickyCartSummaryBar
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CartCheckoutScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.theme.AxomColors
import com.example.ui.theme.AxomMartTheme
import com.google.firebase.firestore.FirebaseFirestore

object AxomRoutes {
    const val ROUTE_HOME = "home"
    const val ROUTE_CATEGORIES = "categories"
    const val ROUTE_ORDERS = "orders"
    const val ROUTE_ACCOUNT = "account"
    const val ROUTE_CART = "cart"
    const val ROUTE_PRODUCT_DETAIL = "product/{productId}"

    fun productDetail(productId: String) = "product/$productId"
}

private enum class TopNavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    HOME(AxomRoutes.ROUTE_HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home),
    CATEGORIES(AxomRoutes.ROUTE_CATEGORIES, "Categories", Icons.Filled.GridView, Icons.Outlined.GridView),
    ORDERS(AxomRoutes.ROUTE_ORDERS, "Orders", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong),
    ACCOUNT(AxomRoutes.ROUTE_ACCOUNT, "Account", Icons.Filled.Person, Icons.Outlined.Person)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AxomMartTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    val context = LocalContext.current
    val databaseId = remember(context) { context.getString(R.string.firestore_database_id) }
    val db = remember(databaseId) { FirebaseFirestore.getInstance(databaseId) }
    val sessionManager = remember(context) { CustomerSessionManager(context.applicationContext) }
    val session by sessionManager.sessionFlow.collectAsStateWithLifecycle()

    val activeSession = session
    if (activeSession == null) {
        val authRepository = remember(db) { FirestoreRepository(db = db) }
        AuthScreen(
            repository = authRepository,
            onSessionEstablished = { newSession ->
                sessionManager.saveSession(newSession)
            }
        )
    } else {
        key(activeSession.customerId) {
            val viewModel: AxomViewModel = viewModel(
                key = activeSession.customerId,
                factory = viewModelFactory {
                    initializer {
                        AxomViewModel(
                            repository = FirestoreRepository(
                                db = db,
                                activeCustomerId = activeSession.customerId
                            ),
                            session = activeSession
                        )
                    }
                }
            )
            AxomMartApp(
                viewModel = viewModel,
                onSignOut = {
                    sessionManager.clearSession()
                }
            )
        }
    }
}

@Composable
fun AxomMartApp(
    viewModel: AxomViewModel,
    onSignOut: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: AxomRoutes.ROUTE_HOME

    var showLocationSheet by remember { mutableStateOf(false) }

    val isTopTab = TopNavTab.entries.any { it.route == currentRoute }
    val showStickyCart = isTopTab && uiState.totalCartCount > 0

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(AxomColors.CanvasSlate)
    ) {
        val useNavigationRail = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useNavigationRail && isTopTab) {
                Surface(
                    color = AxomColors.CardWhite,
                    border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
                    modifier = Modifier.fillMaxHeight()
                ) {
                    NavigationRail(
                        containerColor = AxomColors.CardWhite,
                        modifier = Modifier
                            .windowInsetsPadding(WindowInsets.statusBars)
                            .windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        Spacer(modifier = Modifier.weight(0.2f))
                        TopNavTab.entries.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTopTab(navController, tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = AxomColors.EmeraldPrimary,
                                    selectedTextColor = AxomColors.EmeraldPrimary,
                                    unselectedIconColor = AxomColors.TextInactiveNav,
                                    unselectedTextColor = AxomColors.TextInactiveNav,
                                    indicatorColor = AxomColors.EmeraldSoftBg
                                ),
                                modifier = Modifier.testTag("nav_rail_${tab.route}")
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                val bottomPadding = if (showStickyCart) 80.dp else 8.dp

                Column(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .then(
                                if (isTopTab) Modifier.windowInsetsPadding(WindowInsets.statusBars)
                                else Modifier
                            )
                    ) {
                        NavHost(
                            navController = navController,
                            startDestination = AxomRoutes.ROUTE_HOME
                        ) {
                            composable(AxomRoutes.ROUTE_HOME) {
                                HomeScreen(
                                    uiState = uiState,
                                    bottomContentPadding = bottomPadding,
                                    onSearchQueryChange = viewModel::updateSearchQuery,
                                    onSelectCategory = viewModel::selectHomeCategory,
                                    onToggleFavoritesOnly = viewModel::toggleFavoritesFilter,
                                    onProductClick = { productId ->
                                        navController.navigate(AxomRoutes.productDetail(productId))
                                    },
                                    onIncrementCart = viewModel::incrementCart,
                                    onDecrementCart = viewModel::decrementCart,
                                    onToggleFavorite = viewModel::toggleFavorite,
                                    onExploreDealsClick = {
                                        navigateToTopTab(navController, AxomRoutes.ROUTE_CATEGORIES)
                                    }
                                )
                            }

                            composable(AxomRoutes.ROUTE_CATEGORIES) {
                                CategoriesScreen(
                                    uiState = uiState,
                                    bottomContentPadding = bottomPadding,
                                    onSelectCategory = viewModel::selectTabCategory,
                                    onSelectSortFilter = viewModel::selectCategorySortFilter,
                                    onProductClick = { productId ->
                                        navController.navigate(AxomRoutes.productDetail(productId))
                                    },
                                    onIncrementCart = viewModel::incrementCart,
                                    onDecrementCart = viewModel::decrementCart,
                                    onToggleFavorite = viewModel::toggleFavorite
                                )
                            }

                            composable(AxomRoutes.ROUTE_ORDERS) {
                                OrdersScreen(
                                    uiState = uiState,
                                    bottomContentPadding = bottomPadding,
                                    onDismissConfirmationBanner = viewModel::clearLastPlacedOrderBanner,
                                    onMarkDelivered = viewModel::markOrderDelivered,
                                    onCancelOrder = viewModel::cancelOrder,
                                    onReorder = { order ->
                                        viewModel.reorder(order) {
                                            navController.navigate(AxomRoutes.ROUTE_CART)
                                        }
                                    },
                                    onBrowseProducts = {
                                        navigateToTopTab(navController, AxomRoutes.ROUTE_HOME)
                                    }
                                )
                            }

                            composable(AxomRoutes.ROUTE_ACCOUNT) {
                                AccountScreen(
                                    uiState = uiState,
                                    bottomContentPadding = bottomPadding,
                                    onSelectAddress = viewModel::selectAddress,
                                    onOpenAddAddressSheet = { showLocationSheet = true },
                                    onUpdateProfile = viewModel::updateProfile,
                                    onSetLeaveAtDoor = viewModel::setLeaveAtDoor,
                                    onSetEcoClothBag = viewModel::setEcoClothBag,
                                    onOpenFavoritesOnHome = {
                                        if (!uiState.showFavoritesOnly) viewModel.toggleFavoritesFilter()
                                        navigateToTopTab(navController, AxomRoutes.ROUTE_HOME)
                                    },
                                    onSignOut = onSignOut
                                )
                            }

                            composable(
                                route = AxomRoutes.ROUTE_PRODUCT_DETAIL,
                                arguments = listOf(navArgument("productId") { type = NavType.StringType })
                            ) { entry ->
                                val productId = entry.arguments?.getString("productId") ?: ""
                                val product = uiState.allProducts.firstOrNull { it.id == productId }
                                    ?: CatalogData.findById(productId)
                                    ?: CatalogData.products.first()
                                ProductDetailScreen(
                                    product = product,
                                    uiState = uiState,
                                    onBack = { navController.popBackStack() },
                                    onProductClick = { nextId ->
                                        navController.navigate(AxomRoutes.productDetail(nextId))
                                    },
                                    onIncrementCart = viewModel::incrementCart,
                                    onDecrementCart = viewModel::decrementCart,
                                    onToggleFavorite = viewModel::toggleFavorite,
                                    onViewCart = { navController.navigate(AxomRoutes.ROUTE_CART) }
                                )
                            }

                            composable(AxomRoutes.ROUTE_CART) {
                                CartCheckoutScreen(
                                    uiState = uiState,
                                    onBack = { navController.popBackStack() },
                                    onOpenLocationPicker = { showLocationSheet = true },
                                    onIncrementCart = viewModel::incrementCart,
                                    onDecrementCart = viewModel::decrementCart,
                                    onSelectDeliverySlot = viewModel::selectDeliverySlot,
                                    onSelectPaymentMethod = viewModel::selectPaymentMethod,
                                    onApplyPromo = viewModel::applyPromoCode,
                                    onClearPromo = viewModel::clearPromoCode,
                                    onPlaceOrder = {
                                        viewModel.placeOrder {
                                            navController.popBackStack()
                                            navigateToTopTab(navController, AxomRoutes.ROUTE_ORDERS)
                                        }
                                    },
                                    onBrowseProducts = {
                                        navController.popBackStack()
                                        navigateToTopTab(navController, AxomRoutes.ROUTE_HOME)
                                    }
                                )
                            }
                        }

                        // Non-crashing Firestore error banner
                        uiState.errorMessage?.let { errMsg ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AxomColors.RedSoftBg,
                                border = BorderStroke(1.dp, AxomColors.RedDiscount.copy(alpha = 0.5f)),
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                                    .fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.ErrorOutline,
                                            contentDescription = null,
                                            tint = AxomColors.RedDiscount,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = errMsg,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = AxomColors.RedDiscount
                                        )
                                    }
                                    IconButton(
                                        onClick = viewModel::dismissError,
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Dismiss error",
                                            tint = AxomColors.RedDiscount,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Sticky Cart Bar directly above Bottom Navigation (or bottom edge on Rail mode)
                        androidx.compose.animation.AnimatedVisibility(
                            visible = showStickyCart,
                            enter = slideInVertically { it } + fadeIn(),
                            exit = slideOutVertically { it } + fadeOut(),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .then(
                                    if (useNavigationRail) Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                                    else Modifier
                                )
                        ) {
                            StickyCartSummaryBar(
                                itemCount = uiState.totalCartCount,
                                totalRupees = uiState.grandTotalRupees,
                                savingsRupees = uiState.itemSavingsRupees + uiState.promoDiscountRupees,
                                onViewCartClick = { navController.navigate(AxomRoutes.ROUTE_CART) }
                            )
                        }
                    }

                    // Bottom Navigation Bar for Compact/Medium screens
                    if (!useNavigationRail && isTopTab) {
                        Surface(
                            color = AxomColors.CardWhite,
                            border = BorderStroke(0.5.dp, AxomColors.BorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(
                                    elevation = 6.dp,
                                    ambientColor = Color(0x140F172A),
                                    spotColor = Color(0x140F172A)
                                )
                        ) {
                            NavigationBar(
                                containerColor = AxomColors.CardWhite,
                                windowInsets = WindowInsets.navigationBars,
                                tonalElevation = 0.dp
                            ) {
                                TopNavTab.entries.forEach { tab ->
                                    val selected = currentRoute == tab.route
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = { navigateToTopTab(navController, tab.route) },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        },
                                        label = {
                                            Text(
                                                text = tab.label,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                                )
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = AxomColors.EmeraldPrimary,
                                            selectedTextColor = AxomColors.EmeraldPrimary,
                                            unselectedIconColor = AxomColors.TextInactiveNav,
                                            unselectedTextColor = AxomColors.TextInactiveNav,
                                            indicatorColor = AxomColors.EmeraldSoftBg
                                        ),
                                        modifier = Modifier.testTag("nav_tab_${tab.route}")
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showLocationSheet) {
        LocationPickerBottomSheet(
            registeredAddress = uiState.selectedAddress,
            addresses = uiState.addresses,
            onSelectAddress = viewModel::selectAddress,
            onAddAddress = viewModel::addAddressInRegisteredArea,
            onDismiss = { showLocationSheet = false }
        )
    }
}

private fun navigateToTopTab(navController: NavHostController, route: String) {
    navController.navigate(route) {
        popUpTo(navController.graph.findStartDestination().id) {
            saveState = true
        }
        launchSingleTop = true
        restoreState = true
    }
}
