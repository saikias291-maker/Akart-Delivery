package com.example.data

import com.example.data.remote.AreaDoc
import com.example.model.Product
import com.example.model.ProductCategory
import com.example.model.PromoOffer

object CatalogData {

    val promoOffers: List<PromoOffer> = listOf(
        PromoOffer(
            code = "AXOM10",
            title = "10% OFF on Assam Specials",
            description = "Save up to ₹80 on orders above ₹249",
            minOrderRupees = 249,
            percentDiscount = 10,
            maxDiscountRupees = 80
        ),
        PromoOffer(
            code = "BIHU50",
            title = "Flat ₹50 OFF",
            description = "Valid on baskets of ₹399 or more",
            minOrderRupees = 399,
            flatDiscountRupees = 50
        ),
        PromoOffer(
            code = "FRESH20",
            title = "Flat ₹20 OFF Produce",
            description = "Quick savings on orders ₹149+",
            minOrderRupees = 149,
            flatDiscountRupees = 20
        )
    )

    val defaultServiceAreas: List<AreaDoc> = listOf(
        AreaDoc(
            id = "guwahati_zoo_road",
            areaId = "guwahati_zoo_road",
            name = "Zoo Road Tiniali, Guwahati",
            city = "Guwahati",
            hubName = "Zoo Road Dark Store",
            pinCodes = listOf("781024"),
            defaultEtaMins = 12L,
            active = true
        ),
        AreaDoc(
            id = "guwahati_gs_road",
            areaId = "guwahati_gs_road",
            name = "GS Road, Christian Basti",
            city = "Guwahati",
            hubName = "Dispur Hub",
            pinCodes = listOf("781005"),
            defaultEtaMins = 15L,
            active = true
        ),
        AreaDoc(
            id = "jorhat_gar_ali",
            areaId = "jorhat_gar_ali",
            name = "Gar-Ali, Jorhat",
            city = "Jorhat",
            hubName = "Jorhat Central Hub",
            pinCodes = listOf("785001"),
            defaultEtaMins = 18L,
            active = true
        ),
        AreaDoc(
            id = "dibrugarh_campus",
            areaId = "dibrugarh_campus",
            name = "Dibrugarh University Gate",
            city = "Dibrugarh",
            hubName = "Dibrugarh South Hub",
            pinCodes = listOf("786004"),
            defaultEtaMins = 20L,
            active = true
        )
    )

    fun resolveAreaId(pinCode: String, area: String): String {
        val cleanPin = pinCode.trim()
        val cleanArea = area.trim().lowercase()
        return when {
            cleanPin == "781024" || cleanArea.contains("zoo road") -> "guwahati_zoo_road"
            cleanPin == "781005" || cleanArea.contains("gs road") || cleanArea.contains("christian basti") || cleanArea.contains("dispur") -> "guwahati_gs_road"
            cleanPin == "785001" || cleanArea.contains("jorhat") -> "jorhat_gar_ali"
            cleanPin == "786004" || cleanArea.contains("dibrugarh") -> "dibrugarh_campus"
            cleanPin.isNotBlank() && cleanPin.all { it.isLetterOrDigit() } -> "area_$cleanPin"
            else -> "guwahati_zoo_road"
        }
    }

    fun categoryFromId(categoryId: String): ProductCategory {
        return ProductCategory.entries.firstOrNull {
            it.id.equals(categoryId.trim(), ignoreCase = true)
        } ?: ProductCategory.TEA_BREWS
    }

    val products: List<Product> = listOf(
        Product(
            id = "tea_orthodox_gold",
            name = "Upper Assam Orthodox Gold Tea",
            unit = "250 g",
            priceRupees = 245,
            mrpRupees = 290,
            category = ProductCategory.TEA_BREWS,
            origin = "Dibrugarh Estate",
            rating = 4.9,
            reviewCount = 412,
            deliveryMins = 12,
            description = "Whole-leaf second flush orthodox black tea plucked from family-run Upper Assam gardens. Yields a bright amber liquor with rich malty warmth.",
            highlights = listOf("Second Flush Whole Leaf", "Zero Dust & Blending", "Vacuum Packed Fresh"),
            imageUrl = "https://images.unsplash.com/photo-1597318181409-cf64d0b5d8a2?auto=format&fit=crop&w=600&q=80",
            isGiTagged = true,
            isFeaturedDeal = true
        ),
        Product(
            id = "tea_jorhat_ctc",
            name = "Jorhat Strong CTC Kadak Chai",
            unit = "500 g",
            priceRupees = 210,
            mrpRupees = 240,
            category = ProductCategory.TEA_BREWS,
            origin = "Toklai Valley, Jorhat",
            rating = 4.8,
            reviewCount = 685,
            deliveryMins = 12,
            description = "Full-bodied, brisk CTC tea granules crafted for morning milk chai with bold aroma and deep copper color.",
            highlights = listOf("High-Strength Brew", "Rich Malty Finish", "Direct Garden Harvest"),
            imageUrl = "https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?auto=format&fit=crop&w=600&q=80",
            isGiTagged = true
        ),
        Product(
            id = "tea_kaziranga_green",
            name = "Kaziranga Organic Green Tea",
            unit = "100 g",
            priceRupees = 185,
            mrpRupees = 220,
            category = ProductCategory.TEA_BREWS,
            origin = "Golaghat Foothills",
            rating = 4.7,
            reviewCount = 194,
            deliveryMins = 12,
            description = "Smooth, grassy steamed green tea leaves grown organically near the Kaziranga foothills with crisp antioxidant richness.",
            highlights = listOf("Certified Organic", "Light Zero-Bitterness Steep", "Resealable Tin"),
            imageUrl = "https://images.unsplash.com/photo-1627435601361-ec25f5b1d0e5?auto=format&fit=crop&w=600&q=80"
        ),
        Product(
            id = "rice_kola_joha",
            name = "Kola Joha Aromatic Assam Rice",
            unit = "1 kg",
            priceRupees = 148,
            mrpRupees = 175,
            category = ProductCategory.RICE_STAPLES,
            origin = "Nagaon Harvest",
            rating = 4.9,
            reviewCount = 528,
            deliveryMins = 12,
            description = "GI-tagged traditional Assamese winter short-grain rice treasured for its naturally sweet aroma and fluffy texture when steamed.",
            highlights = listOf("GI-Tagged Assam Joha", "Aged 8 Months", "Naturally Fragrant"),
            imageUrl = "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80",
            isGiTagged = true,
            isFeaturedDeal = true
        ),
        Product(
            id = "rice_bora_sticky",
            name = "Majuli Bora Chaul (Sticky Rice)",
            unit = "1 kg",
            priceRupees = 135,
            mrpRupees = 160,
            category = ProductCategory.RICE_STAPLES,
            origin = "Majuli River Island",
            rating = 4.8,
            reviewCount = 267,
            deliveryMins = 12,
            description = "Authentic glutinous Bora rice cultivated in alluvial Brahmaputra soil—ideal for jolpan with doi-gur or traditional pitha.",
            highlights = listOf("River-Island Harvest", "Soft & Sticky Texture", "Unpolished Grain"),
            imageUrl = "https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=600&q=80"
        ),
        Product(
            id = "oil_mustard_barpeta",
            name = "Kachi Ghani Pure Mustard Oil",
            unit = "1 L",
            priceRupees = 182,
            mrpRupees = 210,
            category = ProductCategory.RICE_STAPLES,
            origin = "Barpeta Cold-Press Mill",
            rating = 4.8,
            reviewCount = 340,
            deliveryMins = 12,
            description = "Pungent, cold-pressed single-origin black mustard oil essential for Assamese masor tenga and pitika.",
            highlights = listOf("100% Cold Pressed", "No Mineral Oil", "Rich Natural Pungency"),
            imageUrl = "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80",
            isFeaturedDeal = true
        ),
        Product(
            id = "spice_tezpur_combo",
            name = "Tezpur Red Chilli & Haldi Duo",
            unit = "200 g",
            priceRupees = 115,
            mrpRupees = 140,
            category = ProductCategory.RICE_STAPLES,
            origin = "Sonitpur Spice Co-op",
            rating = 4.7,
            reviewCount = 152,
            deliveryMins = 12,
            description = "Stone-ground high-curcumin Lakadong-style turmeric paired with vibrant Tezpur sun-dried chilli powder.",
            highlights = listOf("High Curcumin Haldi", "Zero Artificial Color", "Small-Batch Ground"),
            imageUrl = "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80"
        ),
        Product(
            id = "produce_kaji_nemu",
            name = "Fresh Kaji Nemu (Assam Lemon)",
            unit = "4 pcs",
            priceRupees = 48,
            mrpRupees = 60,
            category = ProductCategory.FRESH_PRODUCE,
            origin = "Golaghat Orchards",
            rating = 4.9,
            reviewCount = 740,
            deliveryMins = 10,
            description = "Assam's signature elongated seedless lemon with intoxicating floral zest—perfect alongside dal, khar, and evening tea.",
            highlights = listOf("GI-Tagged State Fruit", "Picked Within 12 Hours", "Seedless & Juicy"),
            imageUrl = "https://images.unsplash.com/photo-1590502593747-42a996133562?auto=format&fit=crop&w=600&q=80",
            isGiTagged = true,
            isFeaturedDeal = true
        ),
        Product(
            id = "produce_bhut_jolokia",
            name = "Fresh Bhut Jolokia Pods",
            unit = "50 g",
            priceRupees = 65,
            mrpRupees = 80,
            category = ProductCategory.FRESH_PRODUCE,
            origin = "Karbi Anglong Hills",
            rating = 4.8,
            reviewCount = 319,
            deliveryMins = 12,
            description = "Fiery, aromatic fresh king chillies harvested from hill farms in Karbi Anglong. Handle carefully—intense smoky heat.",
            highlights = listOf("GI-Tagged King Chilli", "Smoky Floral Aroma", "Farm-Fresh Pack"),
            imageUrl = "https://images.unsplash.com/photo-1588252303782-cb80119abd6d?auto=format&fit=crop&w=600&q=80",
            isGiTagged = true,
            isLowStock = true
        ),
        Product(
            id = "produce_bananas_kamrup",
            name = "Chenichampa Sweet Bananas",
            unit = "6 pcs",
            priceRupees = 52,
            mrpRupees = 65,
            category = ProductCategory.FRESH_PRODUCE,
            origin = "Kamrup Rural Farms",
            rating = 4.7,
            reviewCount = 215,
            deliveryMins = 10,
            description = "Naturally ripened local Chenichampa bananas prized for creamy sweetness and thin golden peel.",
            highlights = listOf("Carbide-Free Ripening", "Farm Direct", "Sweet Local Variety"),
            imageUrl = "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=600&q=80"
        ),
        Product(
            id = "produce_lai_xaak",
            name = "Organic Lai Xaak (Mustard Greens)",
            unit = "250 g",
            priceRupees = 28,
            mrpRupees = 35,
            category = ProductCategory.FRESH_PRODUCE,
            origin = "Sonapur Morning Market",
            rating = 4.6,
            reviewCount = 188,
            deliveryMins = 10,
            description = "Crisp, broad-leafed Assamese mustard greens harvested at dawn—washed and packed breathable for home kitchens.",
            highlights = listOf("Dawn Harvest", "Pesticide-Free", "Crisp Tender Leaves"),
            imageUrl = "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80"
        ),
        Product(
            id = "produce_pineapples",
            name = "Hmar Hills Sweet Pineapple",
            unit = "1 pc (900 g)",
            priceRupees = 68,
            mrpRupees = 85,
            category = ProductCategory.FRESH_PRODUCE,
            origin = "Cachar & Dima Hasao",
            rating = 4.8,
            reviewCount = 209,
            deliveryMins = 12,
            description = "Sun-sweetened golden pineapple from Assam's hill slopes with tender, non-fibrous core and honeyed juice.",
            highlights = listOf("Naturally Sweet", "Hill-Grown", "Ready to Cut"),
            imageUrl = "https://images.unsplash.com/photo-1550258987-190a2d41a8ba?auto=format&fit=crop&w=600&q=80"
        ),
        Product(
            id = "dairy_purabi_milk",
            name = "Purabi Fresh Toned Milk",
            unit = "500 ml",
            priceRupees = 31,
            mrpRupees = 32,
            category = ProductCategory.DAIRY_BAKERY,
            origin = "Panjabari Dairy, Guwahati",
            rating = 4.9,
            reviewCount = 1120,
            deliveryMins = 10,
            description = "Chilled farm-collected Assamese co-operative toned milk delivered cold straight to your doorstep.",
            highlights = listOf("Chilled Cold-Chain", "Local Dairy Co-op", "Daily Fresh Batch"),
            imageUrl = "https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=600&q=80",
            isFeaturedDeal = true
        ),
        Product(
            id = "dairy_sitajakhala_ghee",
            name = "Sitajakhala Pure Cow Ghee",
            unit = "250 ml",
            priceRupees = 295,
            mrpRupees = 340,
            category = ProductCategory.DAIRY_BAKERY,
            origin = "Morigaon Dairy Co-op",
            rating = 4.9,
            reviewCount = 463,
            deliveryMins = 12,
            description = "Granular, aromatic bilona-style cow ghee crafted by the renowned Sitajakhala milk producers of Assam.",
            highlights = listOf("100% Grass-Fed Cow Milk", "Rich Danedar Texture", "Glass Jar"),
            imageUrl = "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=600&q=80"
        ),
        Product(
            id = "bakery_multigrain_loaf",
            name = "Guwahati Bakery Multigrain Loaf",
            unit = "400 g",
            priceRupees = 55,
            mrpRupees = 65,
            category = ProductCategory.DAIRY_BAKERY,
            origin = "Uzan Bazar Bakehouse",
            rating = 4.6,
            reviewCount = 178,
            deliveryMins = 12,
            description = "Soft, freshly baked morning loaf topped with flax, sesame, and oats—zero preservatives.",
            highlights = listOf("Baked This Morning", "Zero Preservatives", "Whole Wheat & Seeds"),
            imageUrl = "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80"
        ),
        Product(
            id = "snacks_til_pitha",
            name = "Til Pitha & Narikol Laru Box",
            unit = "8 pcs",
            priceRupees = 140,
            mrpRupees = 165,
            category = ProductCategory.SNACKS_SWEETS,
            origin = "Guwahati Women's Kitchen",
            rating = 4.9,
            reviewCount = 398,
            deliveryMins = 15,
            description = "Crisp Bora-rice crepes filled with roasted black sesame & jaggery, paired with tender coconut laru.",
            highlights = listOf("Handmade Fresh", "Pure Black Til & Gur", "Festive Pack"),
            imageUrl = "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80",
            isFeaturedDeal = true
        ),
        Product(
            id = "snacks_manas_honey",
            name = "Brahmaputra Wildflower Honey",
            unit = "350 g",
            priceRupees = 260,
            mrpRupees = 310,
            category = ProductCategory.SNACKS_SWEETS,
            origin = "Manas Forest Foothills",
            rating = 4.8,
            reviewCount = 244,
            deliveryMins = 12,
            description = "Raw, unfiltered multifloral forest honey ethically harvested along the Manas buffer belt.",
            highlights = listOf("Raw & Unheated", "NMR Tested Purity", "No Added Sugar"),
            imageUrl = "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=600&q=80"
        ),
        Product(
            id = "craft_phulam_gamosa",
            name = "Handwoven Cotton Phulam Gamosa",
            unit = "1 pc",
            priceRupees = 195,
            mrpRupees = 250,
            category = ProductCategory.LOCAL_CRAFTS,
            origin = "Sualkuchi Master Weavers",
            rating = 4.9,
            reviewCount = 510,
            deliveryMins = 15,
            description = "Authentic GI-tagged handloom white cotton gamosa woven with intricate crimson floral motifs on traditional throw-shuttle looms.",
            highlights = listOf("GI-Tagged Handloom", "100% Pure Cotton", "Supports Local Weavers"),
            imageUrl = "https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&w=600&q=80",
            isGiTagged = true
        ),
        Product(
            id = "craft_bamboo_strainer",
            name = "Artisan Bamboo Tea Strainer",
            unit = "1 pc",
            priceRupees = 89,
            mrpRupees = 120,
            category = ProductCategory.LOCAL_CRAFTS,
            origin = "Barpeta Cane & Bamboo",
            rating = 4.7,
            reviewCount = 132,
            deliveryMins = 15,
            description = "Finely woven seasoned Assamese bamboo tea strainer—plastic-free, durable, and lightweight for daily chai.",
            highlights = listOf("Eco-Friendly Bamboo", "Fine Mesh Weave", "Plastic-Free Kitchen"),
            imageUrl = "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=600&q=80"
        )
    )

    fun findById(id: String): Product? = products.find { it.id == id }
}
