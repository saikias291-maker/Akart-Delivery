package com.example.data.remote

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class AreaDoc(
    @DocumentId val id: String = "",
    val areaId: String = "",
    val name: String = "",
    val city: String = "",
    val hubName: String = "",
    val pinCodes: List<String> = emptyList(),
    val defaultEtaMins: Long = 12L,
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CategoryDoc(
    @DocumentId val id: String = "",
    val categoryId: String = "",
    val title: String = "",
    val shortTitle: String = "",
    val tagline: String = "",
    val imageUrl: String = "",
    val sortOrder: Long = 0L,
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ProductDoc(
    @DocumentId val id: String = "",
    val productId: String = "",
    val name: String = "",
    val unit: String = "",
    val categoryId: String = "",
    val origin: String = "",
    val basePriceRupees: Long = 0L,
    val baseMrpRupees: Long = 0L,
    val rating: Double = 4.8,
    val reviewCount: Long = 0L,
    val deliveryMins: Long = 12L,
    val description: String = "",
    val highlights: List<String> = emptyList(),
    val imageUrl: String = "",
    val photoUrls: List<String> = emptyList(),
    val giTagged: Boolean = false,
    val featuredDeal: Boolean = false,
    val lowStock: Boolean = false,
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AreaPriceDoc(
    @DocumentId val id: String = "",
    val areaId: String = "",
    val productId: String = "",
    val priceRupees: Long = 0L,
    val mrpRupees: Long = 0L,
    val deliveryMins: Long = 12L,
    val available: Boolean = true,
    val stockCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserProfileDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val phone: String = "",
    val primaryAreaId: String = "",
    val leaveAtDoor: Boolean = false,
    val ecoClothBag: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CartItemDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val productId: String = "",
    val quantity: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AddressDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val areaId: String = "",
    val label: String = "",
    val area: String = "",
    val fullAddress: String = "",
    val pinCode: String = "",
    val hubName: String = "",
    val etaMins: Long = 12L,
    val selected: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FavoriteDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val productId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class OrderDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val areaId: String = "",
    val addressLabel: String = "",
    val addressSummary: String = "",
    val deliverySlot: String = "",
    val paymentMethod: String = "",
    val itemCount: Long = 0L,
    val itemsSummary: String = "",
    val productIdsCsv: String = "",
    val subtotalRupees: Long = 0L,
    val deliveryFeeRupees: Long = 0L,
    val discountRupees: Long = 0L,
    val totalRupees: Long = 0L,
    val status: String = "CONFIRMED",
    val deliveryPartnerNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
