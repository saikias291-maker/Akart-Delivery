package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.CatalogData
import com.example.model.CartLineItem
import com.example.model.DeliveryAddress
import com.example.model.DeliverySlot
import com.example.model.OrderRecord
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.Product
import com.example.model.UserPreferences
import com.example.ui.auth.CustomerSession
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

interface AxomDataRepository {
    fun observeServiceAreas(): Flow<List<AreaDoc>>
    fun observeHasAnyAreaPrices(): Flow<Boolean>
    fun observeProducts(customerId: String): Flow<List<Product>>
    fun observeAreaPrices(customerId: String, areaId: String): Flow<Map<String, AreaPriceDoc>>
    fun observeUserPreferences(customerId: String): Flow<UserPreferences>
    fun observeRawCartItems(customerId: String): Flow<List<CartItemDoc>>
    fun observeAddresses(customerId: String): Flow<List<DeliveryAddress>>
    fun observeFavoriteIds(customerId: String): Flow<Set<String>>
    fun observeOrders(customerId: String): Flow<List<OrderRecord>>

    suspend fun registerCustomer(
        fullName: String,
        mobileNumber: String,
        area: AreaDoc,
        fullAddress: String
    ): Result<CustomerSession>

    suspend fun retrieveCustomerByMobile(mobileNumber: String): Result<CustomerSession>
    suspend fun setCartQuantity(productId: String, quantity: Int): Result<Unit>
    suspend fun toggleFavorite(productId: String): Result<Unit>
    suspend fun selectAddress(addressDocId: String): Result<Unit>
    suspend fun addAddressInRegisteredArea(
        label: String,
        fullAddress: String,
        registeredAddress: DeliveryAddress
    ): Result<Unit>

    suspend fun placeOrder(
        items: List<CartLineItem>,
        address: DeliveryAddress,
        slot: DeliverySlot,
        paymentMethod: PaymentMethod,
        subtotal: Int,
        deliveryFee: Int,
        discount: Int,
        total: Int
    ): Result<String>

    suspend fun updateOrderStatus(orderId: String, status: OrderStatus): Result<Unit>
    suspend fun reorderItems(order: OrderRecord, validProductIds: Set<String> = emptySet()): Result<Unit>
    suspend fun updateProfile(name: String, phone: String): Result<Unit>
    suspend fun setLeaveAtDoor(enabled: Boolean): Result<Unit>
    suspend fun setEcoClothBag(enabled: Boolean): Result<Unit>
}

class FirestoreRepository(
    private val db: FirebaseFirestore,
    private val activeCustomerId: String = ""
) : AxomDataRepository {
    constructor(context: Context, activeCustomerId: String = "") : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        activeCustomerId = activeCustomerId
    )

    private fun requireCustomerId(): String {
        return activeCustomerId.trim().takeIf { it.isNotBlank() && it.matches(ID_REGEX) }
            ?: throw IllegalStateException("Customer must be registered or logged in before accessing data.")
    }

    private fun userDocRef(uid: String) = db.collection("users").document(uid)

    override fun observeServiceAreas(): Flow<List<AreaDoc>> = flow {
        val path = "areas"
        db.collection("areas")
            .snapshots()
            .map { snapshot ->
                val docs = snapshot.toObjects(
                    AreaDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).filter { it.active && it.areaId.isNotBlank() && it.name.isNotBlank() }
                if (docs.isEmpty()) {
                    CatalogData.defaultServiceAreas
                } else {
                    docs.sortedBy { it.name.lowercase() }
                }
            }
            .catch { error ->
                logAndRethrowIfRelevant(error, OperationType.LIST, path, null)
            }
            .collect { emit(it) }
    }

    override fun observeHasAnyAreaPrices(): Flow<Boolean> = flow {
        val path = "areaPrices"
        db.collection("areaPrices")
            .limit(1)
            .snapshots()
            .map { !it.isEmpty }
            .catch { error ->
                logAndRethrowIfRelevant(error, OperationType.LIST, path, null)
            }
            .collect { emit(it) }
    }

    override fun observeProducts(customerId: String): Flow<List<Product>> = flow {
        require(customerId.isNotBlank()) { "Customer ID must not be blank" }
        val path = "products"
        db.collection("products")
            .snapshots()
            .map { snapshot ->
                val docs = snapshot.toObjects(
                    ProductDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                if (docs.isEmpty()) {
                    CatalogData.products
                } else {
                    docs.filter { it.active }.mapNotNull { doc ->
                        val pid = doc.productId.ifBlank { doc.id }
                        if (pid.isBlank()) null
                        else Product(
                            id = pid,
                            name = doc.name,
                            unit = doc.unit,
                            priceRupees = doc.basePriceRupees.toInt().coerceAtLeast(1),
                            mrpRupees = doc.baseMrpRupees.toInt().coerceAtLeast(doc.basePriceRupees.toInt().coerceAtLeast(1)),
                            category = CatalogData.categoryFromId(doc.categoryId),
                            origin = doc.origin,
                            rating = doc.rating,
                            reviewCount = doc.reviewCount.toInt(),
                            deliveryMins = doc.deliveryMins.toInt().coerceAtLeast(5),
                            description = doc.description,
                            highlights = doc.highlights,
                            imageUrl = doc.imageUrl.ifBlank { doc.photoUrls.firstOrNull().orEmpty() },
                            isGiTagged = doc.giTagged,
                            isFeaturedDeal = doc.featuredDeal,
                            isLowStock = doc.lowStock,
                            isAvailableInArea = true
                        )
                    }
                }
            }
            .catch { error ->
                logAndRethrowIfRelevant(error, OperationType.LIST, path, customerId)
            }
            .collect { emit(it) }
    }

    override fun observeAreaPrices(customerId: String, areaId: String): Flow<Map<String, AreaPriceDoc>> = flow {
        require(customerId.isNotBlank()) { "Customer ID must not be blank" }
        if (areaId.isBlank()) {
            emit(emptyMap())
            return@flow
        }
        val path = "areaPrices"
        db.collection("areaPrices")
            .whereEqualTo("areaId", areaId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    AreaPriceDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                    .filter { it.productId.isNotBlank() }
                    .associateBy { it.productId }
            }
            .catch { error ->
                logAndRethrowIfRelevant(error, OperationType.LIST, path, customerId)
            }
            .collect { emit(it) }
    }

    override fun observeUserPreferences(customerId: String): Flow<UserPreferences> = flow {
        require(customerId.isNotBlank()) { "Customer ID must not be blank" }
        val path = "users/$customerId"
        userDocRef(customerId)
            .snapshots()
            .map { snapshot ->
                val doc = snapshot.toObject(
                    UserProfileDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                if (doc != null) {
                    UserPreferences(
                        shopperName = doc.displayName,
                        shopperPhone = doc.phone,
                        primaryAreaId = doc.primaryAreaId,
                        leaveAtDoor = doc.leaveAtDoor,
                        ecoClothBag = doc.ecoClothBag
                    )
                } else {
                    UserPreferences()
                }
            }
            .catch { error ->
                logAndRethrowIfRelevant(error, OperationType.GET, path, customerId)
            }
            .collect { emit(it) }
    }

    override fun observeRawCartItems(customerId: String): Flow<List<CartItemDoc>> = flow {
        require(customerId.isNotBlank()) { "Customer ID must not be blank" }
        val path = "users/$customerId/cartItems"
        userDocRef(customerId).collection("cartItems")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    CartItemDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).filter { it.quantity > 0L && it.productId.isNotBlank() }
            }
            .catch { error ->
                logAndRethrowIfRelevant(error, OperationType.LIST, path, customerId)
            }
            .collect { emit(it) }
    }

    override fun observeAddresses(customerId: String): Flow<List<DeliveryAddress>> = flow {
        require(customerId.isNotBlank()) { "Customer ID must not be blank" }
        val path = "users/$customerId/addresses"
        userDocRef(customerId).collection("addresses")
            .snapshots()
            .map { snapshot ->
                val docs = snapshot.toObjects(
                    AddressDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                docs.mapIndexed { idx, doc ->
                    val resolvedAreaId = doc.areaId.ifBlank {
                        CatalogData.resolveAreaId(doc.pinCode, doc.area)
                    }
                    DeliveryAddress(
                        id = (idx + 1).toLong(),
                        docId = doc.id,
                        areaId = resolvedAreaId,
                        label = doc.label,
                        area = doc.area,
                        fullAddress = doc.fullAddress,
                        pinCode = doc.pinCode,
                        hubName = doc.hubName,
                        etaMins = doc.etaMins.toInt(),
                        isSelected = doc.selected
                    )
                }.sortedWith(compareByDescending<DeliveryAddress> { it.isSelected }.thenBy { it.label })
            }
            .catch { error ->
                logAndRethrowIfRelevant(error, OperationType.LIST, path, customerId)
            }
            .collect { emit(it) }
    }

    override fun observeFavoriteIds(customerId: String): Flow<Set<String>> = flow {
        require(customerId.isNotBlank()) { "Customer ID must not be blank" }
        val path = "users/$customerId/favorites"
        userDocRef(customerId).collection("favorites")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    FavoriteDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).map { it.productId }.toSet()
            }
            .catch { error ->
                logAndRethrowIfRelevant(error, OperationType.LIST, path, customerId)
            }
            .collect { emit(it) }
    }

    override fun observeOrders(customerId: String): Flow<List<OrderRecord>> = flow {
        require(customerId.isNotBlank()) { "Customer ID must not be blank" }
        val path = "users/$customerId/orders"
        userDocRef(customerId).collection("orders")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    OrderDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ).map { doc ->
                    val status = enumValues<OrderStatus>()
                        .firstOrNull { it.name == doc.status }
                        ?: OrderStatus.CONFIRMED
                    val millis = (doc.createdAt ?: Timestamp.now()).toDate().time
                    OrderRecord(
                        orderId = doc.id,
                        createdAtMillis = millis,
                        areaId = doc.areaId,
                        addressLabel = doc.addressLabel,
                        addressSummary = doc.addressSummary,
                        deliverySlot = doc.deliverySlot,
                        paymentMethod = doc.paymentMethod,
                        itemCount = doc.itemCount.toInt(),
                        itemsSummary = doc.itemsSummary,
                        productIdsCsv = doc.productIdsCsv,
                        subtotalRupees = doc.subtotalRupees.toInt(),
                        deliveryFeeRupees = doc.deliveryFeeRupees.toInt(),
                        discountRupees = doc.discountRupees.toInt(),
                        totalRupees = doc.totalRupees.toInt(),
                        status = status,
                        deliveryPartnerNote = doc.deliveryPartnerNote
                    )
                }
            }
            .catch { error ->
                logAndRethrowIfRelevant(error, OperationType.LIST, path, customerId)
            }
            .collect { emit(it) }
    }

    override suspend fun registerCustomer(
        fullName: String,
        mobileNumber: String,
        area: AreaDoc,
        fullAddress: String
    ): Result<CustomerSession> {
        var path = "users"
        return try {
            val cleanName = fullName.trim().take(80)
            val cleanMobile = mobileNumber.trim()
            val cleanAddress = fullAddress.trim().take(250)
            val cleanAreaId = area.areaId.trim()

            require(cleanName.length >= 2) { "Please enter your full name (at least 2 characters)." }
            require(cleanMobile.matches(MOBILE_REGEX)) { "Please enter an exact 10-digit mobile number." }
            require(cleanAreaId.isNotEmpty() && cleanAreaId.matches(ID_REGEX)) { "Please select a valid delivery area." }
            require(cleanAddress.length >= 5) { "Please enter your full delivery address (at least 5 characters)." }

            val customerId = "cust_${UUID.randomUUID().toString().replace("-", "")}"
            val userRef = userDocRef(customerId)
            path = userRef.path

            val pinCode = area.pinCodes.firstOrNull()?.trim()?.take(12)?.ifBlank { "781001" } ?: "781001"
            val hubName = area.hubName.trim().take(80).ifBlank { "${area.city.ifBlank { area.name }} Hub" }
            val areaName = area.name.trim().take(100)
            val etaMins = area.defaultEtaMins.coerceIn(1L, 120L)

            val batch = db.batch()
            batch.set(
                userRef,
                mapOf(
                    "userId" to customerId,
                    "displayName" to cleanName,
                    "phone" to cleanMobile,
                    "primaryAreaId" to cleanAreaId,
                    "leaveAtDoor" to false,
                    "ecoClothBag" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            val addrRef = userRef.collection("addresses").document("addr_primary")
            batch.set(
                addrRef,
                mapOf(
                    "userId" to customerId,
                    "areaId" to cleanAreaId,
                    "label" to "Home",
                    "area" to areaName,
                    "fullAddress" to cleanAddress,
                    "pinCode" to pinCode,
                    "hubName" to hubName,
                    "etaMins" to etaMins,
                    "selected" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()

            Result.success(
                CustomerSession(
                    customerId = customerId,
                    fullName = cleanName,
                    mobileNumber = cleanMobile,
                    areaId = cleanAreaId,
                    areaName = areaName,
                    hubName = hubName,
                    etaMins = etaMins.toInt(),
                    fullAddress = cleanAddress
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    override suspend fun retrieveCustomerByMobile(mobileNumber: String): Result<CustomerSession> {
        val path = "users"
        return try {
            val cleanMobile = mobileNumber.trim()
            require(cleanMobile.matches(MOBILE_REGEX)) { "Please enter an exact 10-digit mobile number." }

            val candidates = listOf(
                cleanMobile,
                "+91$cleanMobile",
                "+91 $cleanMobile",
                "+91 ${cleanMobile.take(5)} ${cleanMobile.drop(5)}"
            )
            val querySnap = db.collection("users")
                .whereIn("phone", candidates)
                .limit(5)
                .get()
                .await()

            val profile = querySnap.toObjects(
                UserProfileDoc::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
                .filter { it.userId.isNotBlank() || it.id.isNotBlank() }
                .sortedByDescending { it.updatedAt?.seconds ?: it.createdAt?.seconds ?: 0L }
                .firstOrNull()
                ?: throw IllegalStateException("No customer profile found for $cleanMobile. Please register first.")

            val customerId = profile.userId.ifBlank { profile.id }
            val addressesSnap = userDocRef(customerId).collection("addresses")
                .limit(10)
                .get()
                .await()
            val addressDocs = addressesSnap.toObjects(
                AddressDoc::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            val primaryAddr = addressDocs.firstOrNull { it.selected } ?: addressDocs.firstOrNull()

            val resolvedAreaId = profile.primaryAreaId.ifBlank {
                primaryAddr?.areaId.orEmpty().ifBlank {
                    CatalogData.resolveAreaId(primaryAddr?.pinCode.orEmpty(), primaryAddr?.area.orEmpty())
                }
            }

            val areaDoc = runCatching {
                if (resolvedAreaId.isNotBlank()) {
                    db.collection("areas").document(resolvedAreaId).get().await()
                        .toObject(AreaDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else null
            }.getOrNull() ?: CatalogData.defaultServiceAreas.firstOrNull { it.areaId == resolvedAreaId }

            val normalizedPhone = profile.phone.filter { it.isDigit() }.takeLast(10)
                .ifBlank { cleanMobile }

            Result.success(
                CustomerSession(
                    customerId = customerId,
                    fullName = profile.displayName.ifBlank { "AKART Customer" },
                    mobileNumber = normalizedPhone,
                    areaId = resolvedAreaId,
                    areaName = areaDoc?.name?.takeIf { it.isNotBlank() }
                        ?: primaryAddr?.area.orEmpty().ifBlank { resolvedAreaId },
                    hubName = areaDoc?.hubName?.takeIf { it.isNotBlank() }
                        ?: primaryAddr?.hubName.orEmpty().ifBlank { "Local Hub" },
                    etaMins = (areaDoc?.defaultEtaMins ?: primaryAddr?.etaMins ?: 15L).toInt().coerceIn(1, 120),
                    fullAddress = primaryAddr?.fullAddress.orEmpty()
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    override suspend fun setCartQuantity(productId: String, quantity: Int): Result<Unit> {
        var path = "users/cartItems/$productId"
        return try {
            val uid = requireCustomerId()
            require(productId.isNotBlank() && productId.matches(ID_REGEX)) { "Invalid product ID" }
            val docRef = userDocRef(uid).collection("cartItems").document(productId)
            path = docRef.path
            if (quantity <= 0) {
                docRef.delete().await()
            } else {
                val boundedQty = quantity.coerceIn(1, 99).toLong()
                val existing = docRef.get().await()
                if (existing.exists()) {
                    docRef.update(
                        mapOf(
                            "quantity" to boundedQty,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                } else {
                    docRef.set(
                        mapOf(
                            "userId" to uid,
                            "productId" to productId,
                            "quantity" to boundedQty,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    override suspend fun toggleFavorite(productId: String): Result<Unit> {
        var path = "users/favorites/$productId"
        return try {
            val uid = requireCustomerId()
            require(productId.isNotBlank() && productId.matches(ID_REGEX)) { "Invalid product ID" }
            val docRef = userDocRef(uid).collection("favorites").document(productId)
            path = docRef.path
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.delete().await()
            } else {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "productId" to productId,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    override suspend fun selectAddress(addressDocId: String): Result<Unit> {
        var path = "users/addresses/$addressDocId"
        return try {
            val uid = requireCustomerId()
            require(addressDocId.isNotBlank() && addressDocId.matches(ID_REGEX)) { "Invalid address ID" }
            val userRef = userDocRef(uid)
            val collectionRef = userRef.collection("addresses")
            path = collectionRef.path
            val snapshot = collectionRef.get().await()
            val batch = db.batch()
            snapshot.documents.forEach { doc ->
                batch.update(
                    doc.reference,
                    mapOf(
                        "selected" to (doc.id == addressDocId),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    override suspend fun addAddressInRegisteredArea(
        label: String,
        fullAddress: String,
        registeredAddress: DeliveryAddress
    ): Result<Unit> {
        var path = "users/addresses"
        return try {
            val uid = requireCustomerId()
            val cleanLabel = label.trim().take(30)
            val cleanFull = fullAddress.trim().take(250)
            val lockedAreaId = registeredAddress.areaId.trim().take(64)
            require(cleanLabel.isNotEmpty() && cleanFull.length >= 5) {
                "Please enter a valid address label and full delivery address."
            }
            require(lockedAreaId.isNotEmpty() && lockedAreaId.matches(ID_REGEX)) {
                "Registered delivery area is required."
            }

            val userRef = userDocRef(uid)
            val collectionRef = userRef.collection("addresses")
            val newDocId = "addr_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val newRef = collectionRef.document(newDocId)
            path = newRef.path

            val existingSnap = collectionRef.get().await()
            val batch = db.batch()
            existingSnap.documents.forEach { doc ->
                batch.update(
                    doc.reference,
                    mapOf(
                        "selected" to false,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.set(
                newRef,
                mapOf(
                    "userId" to uid,
                    "areaId" to lockedAreaId,
                    "label" to cleanLabel,
                    "area" to registeredAddress.area.take(100),
                    "fullAddress" to cleanFull,
                    "pinCode" to registeredAddress.pinCode.ifBlank { "781001" }.take(12),
                    "hubName" to registeredAddress.hubName.ifBlank { "Local Hub" }.take(80),
                    "etaMins" to registeredAddress.etaMins.coerceIn(1, 120).toLong(),
                    "selected" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    override suspend fun placeOrder(
        items: List<CartLineItem>,
        address: DeliveryAddress,
        slot: DeliverySlot,
        paymentMethod: PaymentMethod,
        subtotal: Int,
        deliveryFee: Int,
        discount: Int,
        total: Int
    ): Result<String> {
        var path = "users/orders"
        return try {
            val uid = requireCustomerId()
            require(items.isNotEmpty()) { "Cannot place an empty order" }
            val orderNumber = "AKM-${(3000..9999).random()}"
            val orderRef = userDocRef(uid).collection("orders").document(orderNumber)
            path = orderRef.path

            val resolvedAreaId = address.areaId.ifBlank {
                CatalogData.resolveAreaId(address.pinCode, address.area)
            }.take(64)
            val summary = items.joinToString(", ") { "${it.product.name} ×${it.quantity}" }.take(1000)
            val productIdsCsv = items.joinToString(",") { "${it.product.id}:${it.quantity}" }.take(1000)
            val totalItemsCount = items.sumOf { it.quantity }.coerceIn(1, 500).toLong()

            val batch = db.batch()
            batch.set(
                orderRef,
                mapOf(
                    "userId" to uid,
                    "areaId" to resolvedAreaId,
                    "addressLabel" to address.label.ifBlank { "Home" }.take(40),
                    "addressSummary" to "${address.area} • ${address.pinCode}".take(200),
                    "deliverySlot" to slot.label.take(50),
                    "paymentMethod" to paymentMethod.title.take(50),
                    "itemCount" to totalItemsCount,
                    "itemsSummary" to summary,
                    "productIdsCsv" to productIdsCsv,
                    "subtotalRupees" to subtotal.coerceAtLeast(0).toLong(),
                    "deliveryFeeRupees" to deliveryFee.coerceAtLeast(0).toLong(),
                    "discountRupees" to discount.coerceAtLeast(0).toLong(),
                    "totalRupees" to total.coerceAtLeast(0).toLong(),
                    "status" to OrderStatus.CONFIRMED.name,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            items.forEach { item ->
                val cartRef = userDocRef(uid).collection("cartItems").document(item.product.id)
                batch.delete(cartRef)
            }
            batch.commit().await()
            Result.success(orderNumber)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    override suspend fun updateOrderStatus(orderId: String, status: OrderStatus): Result<Unit> {
        var path = "users/orders/$orderId"
        return try {
            val uid = requireCustomerId()
            require(orderId.isNotBlank() && orderId.matches(ID_REGEX)) { "Invalid order ID" }
            val orderRef = userDocRef(uid).collection("orders").document(orderId)
            path = orderRef.path
            orderRef.update(
                mapOf(
                    "status" to status.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    override suspend fun reorderItems(
        order: OrderRecord,
        validProductIds: Set<String>
    ): Result<Unit> {
        var path = "users/cartItems"
        return try {
            val uid = requireCustomerId()
            val cartCol = userDocRef(uid).collection("cartItems")
            path = cartCol.path
            val existingCartSnap = cartCol.get().await()
            val existingIds = existingCartSnap.documents.map { it.id }.toSet()

            val tokens = order.productIdsCsv.split(",").filter { it.isNotBlank() }
            val batch = db.batch()
            for (token in tokens) {
                val parts = token.split(":")
                val productId = parts.firstOrNull()?.trim() ?: continue
                val existsInCatalog = validProductIds.contains(productId) || CatalogData.findById(productId) != null
                if (!productId.matches(ID_REGEX) || !existsInCatalog) continue
                val qty = (parts.getOrNull(1)?.toIntOrNull() ?: 1).coerceIn(1, 99).toLong()
                val docRef = cartCol.document(productId)
                if (existingIds.contains(productId)) {
                    batch.update(
                        docRef,
                        mapOf(
                            "quantity" to qty,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    batch.set(
                        docRef,
                        mapOf(
                            "userId" to uid,
                            "productId" to productId,
                            "quantity" to qty,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    override suspend fun updateProfile(name: String, phone: String): Result<Unit> {
        var path = "users"
        return try {
            val uid = requireCustomerId()
            val cleanName = name.trim().take(80)
            val cleanPhone = phone.trim()
            require(cleanName.length >= 2) { "Full name must be at least 2 characters." }
            require(cleanPhone.matches(MOBILE_REGEX)) { "Mobile number must be exactly 10 digits." }
            val userRef = userDocRef(uid)
            path = userRef.path
            userRef.update(
                mapOf(
                    "displayName" to cleanName,
                    "phone" to cleanPhone,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    override suspend fun setLeaveAtDoor(enabled: Boolean): Result<Unit> {
        var path = "users"
        return try {
            val uid = requireCustomerId()
            val userRef = userDocRef(uid)
            path = userRef.path
            userRef.update(
                mapOf(
                    "leaveAtDoor" to enabled,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    override suspend fun setEcoClothBag(enabled: Boolean): Result<Unit> {
        var path = "users"
        return try {
            val uid = requireCustomerId()
            val userRef = userDocRef(uid)
            path = userRef.path
            userRef.update(
                mapOf(
                    "ecoClothBag" to enabled,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path, activeCustomerId)
            Result.failure(e)
        }
    }

    private fun logAndRethrowIfRelevant(
        error: Throwable,
        operationType: OperationType,
        path: String,
        expectedCustomerId: String?
    ): Nothing {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null) {
            handleFirestoreError(exceptionToLog, operationType, path, expectedCustomerId)
        }
        throw error
    }

    companion object {
        val ID_REGEX = Regex("^[a-zA-Z0-9_\\-]+$")
        val MOBILE_REGEX = Regex("^[0-9]{10}$")
    }
}
