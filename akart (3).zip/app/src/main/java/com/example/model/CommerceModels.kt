package com.example.model

enum class ProductCategory(
    val id: String,
    val title: String,
    val shortTitle: String,
    val tagline: String
) {
    ALL("all", "All Essentials", "All", "Everything near you"),
    TEA_BREWS("tea", "Assam Tea & Brews", "Assam Tea", "Single-estate gardens"),
    FRESH_PRODUCE("produce", "Fresh Produce", "Produce", "Morning farm harvest"),
    RICE_STAPLES("staples", "Rice & Staples", "Staples", "Joha, Bora & oils"),
    DAIRY_BAKERY("dairy", "Dairy & Bakery", "Dairy", "Purabi & fresh bakes"),
    SNACKS_SWEETS("snacks", "Snacks & Pitha", "Snacks", "Traditional & savory"),
    LOCAL_CRAFTS("crafts", "Weaves & Home", "Crafts", "Sualkuchi & bamboo")
}

data class Product(
    val id: String,
    val name: String,
    val unit: String,
    val priceRupees: Int,
    val mrpRupees: Int,
    val category: ProductCategory,
    val origin: String,
    val rating: Double,
    val reviewCount: Int,
    val deliveryMins: Int,
    val description: String,
    val highlights: List<String>,
    val imageUrl: String,
    val isGiTagged: Boolean = false,
    val isFeaturedDeal: Boolean = false,
    val isLowStock: Boolean = false,
    val isAvailableInArea: Boolean = true
) {
    val discountPercent: Int
        get() = if (mrpRupees > priceRupees) {
            ((mrpRupees - priceRupees) * 100) / mrpRupees
        } else 0
}

data class CartLineItem(
    val product: Product,
    val quantity: Int
) {
    val lineTotalRupees: Int
        get() = product.priceRupees * quantity
    val lineMrpTotalRupees: Int
        get() = product.mrpRupees * quantity
}

enum class DeliverySlot(
    val id: String,
    val label: String,
    val subtitle: String
) {
    EXPRESS("express", "Express 12 min", "Dispatched immediately"),
    MORNING("morning", "Morning 7–9 AM", "Tomorrow morning"),
    EVENING("evening", "Evening 5–7 PM", "Today evening")
}

enum class PaymentMethod(
    val id: String,
    val title: String,
    val subtitle: String
) {
    UPI("upi", "UPI (GPay / PhonePe)", "Instant zero-fee payment"),
    CASH_ON_DELIVERY("cod", "Cash on Delivery", "Pay via cash or QR at door"),
    AXOM_WALLET("wallet", "AxomPay Wallet", "Fast 1-tap checkout")
}

enum class OrderStatus(val stepIndex: Int, val label: String) {
    CONFIRMED(0, "Order Confirmed"),
    PACKED(1, "Packed at Local Hub"),
    OUT_FOR_DELIVERY(2, "Rider on the Way"),
    DELIVERED(3, "Delivered"),
    CANCELLED(-1, "Cancelled")
}

data class DeliveryAddress(
    val id: Long = 0,
    val docId: String = "",
    val areaId: String = "",
    val label: String,
    val area: String,
    val fullAddress: String,
    val pinCode: String,
    val hubName: String,
    val etaMins: Int,
    val isSelected: Boolean = false
)

data class OrderRecord(
    val orderId: String,
    val createdAtMillis: Long,
    val areaId: String = "",
    val addressLabel: String,
    val addressSummary: String,
    val deliverySlot: String,
    val paymentMethod: String,
    val itemCount: Int,
    val itemsSummary: String,
    val productIdsCsv: String,
    val subtotalRupees: Int,
    val deliveryFeeRupees: Int,
    val discountRupees: Int,
    val totalRupees: Int,
    val status: OrderStatus,
    val deliveryPartnerNote: String = ""
)

data class PromoOffer(
    val code: String,
    val title: String,
    val description: String,
    val minOrderRupees: Int,
    val flatDiscountRupees: Int = 0,
    val percentDiscount: Int = 0,
    val maxDiscountRupees: Int = 100
) {
    fun computeDiscount(subtotal: Int): Int {
        if (subtotal < minOrderRupees) return 0
        return if (flatDiscountRupees > 0) {
            flatDiscountRupees
        } else {
            ((subtotal * percentDiscount) / 100).coerceAtMost(maxDiscountRupees)
        }
    }
}

data class UserPreferences(
    val shopperName: String = "",
    val shopperPhone: String = "",
    val primaryAreaId: String = "",
    val leaveAtDoor: Boolean = false,
    val ecoClothBag: Boolean = true
)
