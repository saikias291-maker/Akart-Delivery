package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CatalogData
import com.example.model.ProductCategory
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("AKART", appName)
  }

  @Test
  fun `promo offer discount calculates within limits`() {
    val offer = CatalogData.promoOffers.first { it.code == "AXOM10" }
    assertEquals(0, offer.computeDiscount(200))
    assertEquals(40, offer.computeDiscount(400))
    assertEquals(80, offer.computeDiscount(1200))
  }

  @Test
  fun `area resolver maps Assam PIN codes and area names accurately`() {
    assertEquals("guwahati_zoo_road", CatalogData.resolveAreaId("781024", "Zoo Road Tiniali"))
    assertEquals("guwahati_gs_road", CatalogData.resolveAreaId("781005", "GS Road, Dispur"))
    assertEquals("jorhat_gar_ali", CatalogData.resolveAreaId("785001", "Gar-Ali, Jorhat"))
    assertEquals("dibrugarh_campus", CatalogData.resolveAreaId("786004", "Dibrugarh University"))
    assertEquals("area_784001", CatalogData.resolveAreaId("784001", "Tezpur"))
    assertEquals(ProductCategory.RICE_STAPLES, CatalogData.categoryFromId("staples"))
  }

  @Test
  fun `firebase resources include named firestore database and web client id`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dbId = context.getString(R.string.firestore_database_id)
    val webClientId = context.getString(R.string.default_web_client_id)
    assertEquals("ai-studio-android-akart-4b845dcb-efd6-4cac-ba86-a505a01a4528", dbId)
    org.junit.Assert.assertTrue(webClientId.isNotBlank())
    org.junit.Assert.assertTrue(webClientId.endsWith(".apps.googleusercontent.com"))
  }
}
