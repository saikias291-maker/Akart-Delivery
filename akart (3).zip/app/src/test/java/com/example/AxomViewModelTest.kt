package com.example

import com.example.data.CatalogData
import com.example.data.remote.AreaDoc
import com.example.data.remote.AreaPriceDoc
import com.example.data.remote.AxomDataRepository
import com.example.data.remote.CartItemDoc
import com.example.model.CartLineItem
import com.example.model.DeliveryAddress
import com.example.model.DeliverySlot
import com.example.model.OrderRecord
import com.example.model.OrderStatus
import com.example.model.PaymentMethod
import com.example.model.Product
import com.example.model.UserPreferences
import com.example.ui.AxomViewModel
import com.example.ui.auth.CustomerSession
import com.example.ui.auth.CustomerSessionManager
import com.example.ui.auth.SessionStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestWatcher
import org.junit.runner.Description
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
class MainDispatcherRule(
    private val testDispatcher: TestDispatcher = UnconfinedTestDispatcher()
) : TestWatcher() {
    override fun starting(description: Description) {
        Dispatchers.setMain(testDispatcher)
    }

    override fun finished(description: Description) {
        Dispatchers.resetMain()
    }
}

private class InMemorySessionStorage : SessionStorage {
    private var payload: String? = null
    override fun readSessionJson(): String? = payload
    override fun writeSessionJson(json: String) {
        payload = json
    }
    override fun clearSession() {
        payload = null
    }
}

private class FakeAxomDataRepository : AxomDataRepository {
    val serviceAreasFlow = MutableStateFlow(CatalogData.defaultServiceAreas)
    val hasAnyAreaPricesFlow = MutableStateFlow(true)
    val productsFlow = MutableStateFlow(CatalogData.products)
    val areaPricesByArea = MutableStateFlow<Map<String, Map<String, AreaPriceDoc>>>(emptyMap())
    val preferencesFlow = MutableStateFlow(UserPreferences())
    val cartFlow = MutableStateFlow<List<CartItemDoc>>(emptyList())
    val addressesFlow = MutableStateFlow<List<DeliveryAddress>>(emptyList())
    val favoritesFlow = MutableStateFlow<Set<String>>(emptySet())
    val ordersFlow = MutableStateFlow<List<OrderRecord>>(emptyList())

    var failNextMutation: Throwable? = null
    var lastPlacedOrderAreaId: String? = null
    var lastPlacedOrderTotal: Int? = null

    override fun observeServiceAreas(): Flow<List<AreaDoc>> = serviceAreasFlow

    override fun observeHasAnyAreaPrices(): Flow<Boolean> = hasAnyAreaPricesFlow

    override fun observeProducts(customerId: String): Flow<List<Product>> = productsFlow

    override fun observeAreaPrices(customerId: String, areaId: String): Flow<Map<String, AreaPriceDoc>> =
        areaPricesByArea.map { it[areaId].orEmpty() }

    override fun observeUserPreferences(customerId: String): Flow<UserPreferences> = preferencesFlow

    override fun observeRawCartItems(customerId: String): Flow<List<CartItemDoc>> = cartFlow

    override fun observeAddresses(customerId: String): Flow<List<DeliveryAddress>> = addressesFlow

    override fun observeFavoriteIds(customerId: String): Flow<Set<String>> = favoritesFlow

    override fun observeOrders(customerId: String): Flow<List<OrderRecord>> = ordersFlow

    override suspend fun registerCustomer(
        fullName: String,
        mobileNumber: String,
        area: AreaDoc,
        fullAddress: String
    ): Result<CustomerSession> {
        return Result.success(
            CustomerSession(
                customerId = "cust_fake_1234",
                fullName = fullName.trim(),
                mobileNumber = mobileNumber.trim(),
                areaId = area.areaId,
                areaName = area.name,
                hubName = area.hubName,
                etaMins = area.defaultEtaMins.toInt(),
                fullAddress = fullAddress.trim()
            )
        )
    }

    override suspend fun retrieveCustomerByMobile(mobileNumber: String): Result<CustomerSession> {
        return Result.failure(IllegalStateException("Not found"))
    }

    override suspend fun setCartQuantity(productId: String, quantity: Int): Result<Unit> {
        failNextMutation?.let { err ->
            failNextMutation = null
            return Result.failure(err)
        }
        val current = cartFlow.value.toMutableList()
        current.removeAll { it.productId == productId }
        if (quantity > 0) {
            current.add(CartItemDoc(id = productId, userId = "cust-test", productId = productId, quantity = quantity.toLong()))
        }
        cartFlow.value = current
        return Result.success(Unit)
    }

    override suspend fun toggleFavorite(productId: String): Result<Unit> {
        failNextMutation?.let { err ->
            failNextMutation = null
            return Result.failure(err)
        }
        val updated = favoritesFlow.value.toMutableSet()
        if (!updated.add(productId)) {
            updated.remove(productId)
        }
        favoritesFlow.value = updated
        return Result.success(Unit)
    }

    override suspend fun selectAddress(addressDocId: String): Result<Unit> {
        failNextMutation?.let { err ->
            failNextMutation = null
            return Result.failure(err)
        }
        addressesFlow.value = addressesFlow.value.map { addr ->
            addr.copy(isSelected = addr.docId == addressDocId)
        }
        return Result.success(Unit)
    }

    override suspend fun addAddressInRegisteredArea(
        label: String,
        fullAddress: String,
        registeredAddress: DeliveryAddress
    ): Result<Unit> {
        val newAddr = DeliveryAddress(
            id = (addressesFlow.value.size + 1).toLong(),
            docId = "addr_custom_${addressesFlow.value.size}",
            areaId = registeredAddress.areaId,
            label = label,
            area = registeredAddress.area,
            fullAddress = fullAddress,
            pinCode = registeredAddress.pinCode,
            hubName = registeredAddress.hubName,
            etaMins = registeredAddress.etaMins,
            isSelected = true
        )
        addressesFlow.value = addressesFlow.value.map { it.copy(isSelected = false) } + newAddr
        return Result.success(Unit)
    }

    override suspend fun placeOrder(
        items: List<CartLineItem>,
        address: DeliveryAddress,
        slot: DeliverySlot,
        paymentMethod: PaymentMethod,
        subtotal: Int,
        deliveryFee: Int,
        discount: Int,
        total: Int
    ): Result<String> {
        failNextMutation?.let { err ->
            failNextMutation = null
            return Result.failure(err)
        }
        val orderId = "AKM-7777"
        lastPlacedOrderAreaId = address.areaId
        lastPlacedOrderTotal = total
        val record = OrderRecord(
            orderId = orderId,
            createdAtMillis = 1_700_000_000_000L,
            areaId = address.areaId,
            addressLabel = address.label,
            addressSummary = "${address.area} • ${address.pinCode}",
            deliverySlot = slot.label,
            paymentMethod = paymentMethod.title,
            itemCount = items.sumOf { it.quantity },
            itemsSummary = items.joinToString(", ") { "${it.product.name} ×${it.quantity}" },
            productIdsCsv = items.joinToString(",") { "${it.product.id}:${it.quantity}" },
            subtotalRupees = subtotal,
            deliveryFeeRupees = deliveryFee,
            discountRupees = discount,
            totalRupees = total,
            status = OrderStatus.CONFIRMED
        )
        ordersFlow.value = listOf(record) + ordersFlow.value
        cartFlow.value = emptyList()
        return Result.success(orderId)
    }

    override suspend fun updateOrderStatus(orderId: String, status: OrderStatus): Result<Unit> {
        ordersFlow.value = ordersFlow.value.map { order ->
            if (order.orderId == orderId) order.copy(status = status) else order
        }
        return Result.success(Unit)
    }

    override suspend fun reorderItems(order: OrderRecord, validProductIds: Set<String>): Result<Unit> {
        val next = mutableListOf<CartItemDoc>()
        order.productIdsCsv.split(",").filter { it.isNotBlank() }.forEach { token ->
            val parts = token.split(":")
            val pid = parts.firstOrNull()?.trim() ?: return@forEach
            val qty = (parts.getOrNull(1)?.toIntOrNull() ?: 1).toLong()
            if (validProductIds.isEmpty() || validProductIds.contains(pid)) {
                next.add(CartItemDoc(id = pid, userId = "cust-test", productId = pid, quantity = qty))
            }
        }
        cartFlow.value = next
        return Result.success(Unit)
    }

    override suspend fun updateProfile(name: String, phone: String): Result<Unit> {
        preferencesFlow.value = preferencesFlow.value.copy(shopperName = name, shopperPhone = phone)
        return Result.success(Unit)
    }

    override suspend fun setLeaveAtDoor(enabled: Boolean): Result<Unit> {
        preferencesFlow.value = preferencesFlow.value.copy(leaveAtDoor = enabled)
        return Result.success(Unit)
    }

    override suspend fun setEcoClothBag(enabled: Boolean): Result<Unit> {
        preferencesFlow.value = preferencesFlow.value.copy(ecoClothBag = enabled)
        return Result.success(Unit)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AxomViewModelTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private fun testSession(areaId: String = "guwahati_zoo_road") = CustomerSession(
        customerId = "cust_test_001",
        fullName = "Bhaskar Das",
        mobileNumber = "9864012345",
        areaId = areaId,
        areaName = if (areaId == "jorhat_gar_ali") "Gar-Ali, Jorhat" else "Zoo Road Tiniali, Guwahati",
        hubName = if (areaId == "jorhat_gar_ali") "Jorhat Central Hub" else "Zoo Road Dark Store",
        etaMins = if (areaId == "jorhat_gar_ali") 18 else 12,
        fullAddress = "House 14, Bylane 3"
    )

    @Test
    fun `registered area strictly filters products and applies area-specific prices`() = runTest {
        val repo = FakeAxomDataRepository()
        repo.hasAnyAreaPricesFlow.value = true
        repo.areaPricesByArea.value = mapOf(
            "jorhat_gar_ali" to mapOf(
                "tea_orthodox_gold" to AreaPriceDoc(
                    id = "jorhat_gar_ali__tea_orthodox_gold",
                    areaId = "jorhat_gar_ali",
                    productId = "tea_orthodox_gold",
                    priceRupees = 195L,
                    mrpRupees = 290L,
                    deliveryMins = 15L,
                    available = true
                ),
                "produce_kaji_nemu" to AreaPriceDoc(
                    id = "jorhat_gar_ali__produce_kaji_nemu",
                    areaId = "jorhat_gar_ali",
                    productId = "produce_kaji_nemu",
                    priceRupees = 45L,
                    mrpRupees = 60L,
                    deliveryMins = 16L,
                    available = false
                )
            )
        )

        val vm = AxomViewModel(repo, session = testSession("jorhat_gar_ali"))
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { vm.uiState.collect() }

        val state = vm.uiState.value
        assertEquals("jorhat_gar_ali", state.registeredAreaId)
        assertEquals(1, state.allProducts.size)
        assertEquals("tea_orthodox_gold", state.allProducts.first().id)
        assertEquals(195, state.allProducts.first().priceRupees)
        assertFalse(state.allProducts.any { it.id == "produce_kaji_nemu" })

        vm.incrementCart("tea_orthodox_gold")
        val afterCart = vm.uiState.value
        assertEquals(195, afterCart.cartSubtotalRupees)
        assertEquals(25, afterCart.deliveryFeeRupees)
        assertEquals(220, afterCart.grandTotalRupees)
    }

    @Test
    fun `placeOrder records registered areaId total clears promo and updates order history`() = runTest {
        val repo = FakeAxomDataRepository()
        repo.areaPricesByArea.value = mapOf(
            "guwahati_zoo_road" to mapOf(
                "tea_orthodox_gold" to AreaPriceDoc(
                    areaId = "guwahati_zoo_road",
                    productId = "tea_orthodox_gold",
                    priceRupees = 220L,
                    mrpRupees = 280L,
                    deliveryMins = 12L,
                    available = true
                )
            )
        )

        val vm = AxomViewModel(repo, session = testSession("guwahati_zoo_road"))
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { vm.uiState.collect() }

        vm.incrementCart("tea_orthodox_gold")
        vm.incrementCart("tea_orthodox_gold")
        vm.applyPromoCode("AXOM10")
        assertEquals(440, vm.uiState.value.cartSubtotalRupees)
        assertEquals(44, vm.uiState.value.promoDiscountRupees)
        assertEquals(396, vm.uiState.value.grandTotalRupees)

        var createdId: String? = null
        vm.placeOrder { createdId = it }

        assertEquals("AKM-7777", createdId)
        assertEquals("guwahati_zoo_road", repo.lastPlacedOrderAreaId)
        assertEquals(396, repo.lastPlacedOrderTotal)
        assertTrue(vm.uiState.value.cartItems.isEmpty())
        assertNull(vm.uiState.value.appliedPromoCode)
        assertEquals("AKM-7777", vm.uiState.value.lastPlacedOrderId)
        assertEquals("AKM-7777", vm.uiState.value.orders.first().orderId)

        vm.markOrderDelivered("AKM-7777")
        assertEquals(OrderStatus.DELIVERED, vm.uiState.value.orders.first().status)

        vm.reorder(vm.uiState.value.orders.first()) {}
        assertEquals(2, vm.uiState.value.cartQuantities["tea_orthodox_gold"])
    }

    @Test
    fun `mutation failure surfaces errorMessage and dismissError clears it`() = runTest {
        val repo = FakeAxomDataRepository()
        val vm = AxomViewModel(repo, session = testSession())
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { vm.uiState.collect() }

        repo.failNextMutation = IllegalStateException("Permission denied on test write")
        vm.toggleFavorite("tea_orthodox_gold")

        assertNotNull(vm.uiState.value.errorMessage)
        assertTrue(vm.uiState.value.errorMessage!!.contains("Permission denied"))

        vm.dismissError()
        assertNull(vm.uiState.value.errorMessage)
    }

    @Test
    fun `profile validates 10-digit mobile updates preferences and favorites filter`() = runTest {
        val repo = FakeAxomDataRepository()
        repo.hasAnyAreaPricesFlow.value = false
        val vm = AxomViewModel(repo, session = testSession())
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { vm.uiState.collect() }

        vm.updateProfile("Bikash", "12345")
        assertNotNull(vm.uiState.value.errorMessage)
        vm.dismissError()

        vm.updateProfile("Bikash Hazarika", "9864011223")
        vm.setLeaveAtDoor(true)
        vm.setEcoClothBag(false)
        assertEquals("Bikash Hazarika", vm.uiState.value.userPreferences.shopperName)
        assertEquals("9864011223", vm.uiState.value.userPreferences.shopperPhone)
        assertTrue(vm.uiState.value.userPreferences.leaveAtDoor)
        assertFalse(vm.uiState.value.userPreferences.ecoClothBag)

        vm.toggleFavorite("tea_orthodox_gold")
        vm.toggleFavoritesFilter()
        assertEquals(1, vm.uiState.value.homeFilteredProducts.size)
        assertEquals("tea_orthodox_gold", vm.uiState.value.homeFilteredProducts.first().id)
    }

    @Test
    fun `session manager persists restores on relaunch and clears on logout`() {
        val storage = InMemorySessionStorage()
        val manager1 = CustomerSessionManager(storage)
        assertNull(manager1.sessionFlow.value)

        val session = testSession()
        manager1.saveSession(session)
        assertEquals(session, manager1.sessionFlow.value)

        val manager2 = CustomerSessionManager(storage)
        assertEquals(session, manager2.sessionFlow.value)

        manager2.clearSession()
        assertNull(manager2.sessionFlow.value)
        assertNull(CustomerSessionManager(storage).sessionFlow.value)
    }
}
